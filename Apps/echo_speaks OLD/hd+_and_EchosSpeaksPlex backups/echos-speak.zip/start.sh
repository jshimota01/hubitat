
#!/bin/sh

node /app/src/hdPlusMakerProxy.js &
exec node /app/src/server.js

