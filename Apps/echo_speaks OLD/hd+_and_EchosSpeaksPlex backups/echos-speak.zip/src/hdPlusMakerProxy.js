const http = require('http');
const net = require('net');
const { URL } = require('url');

const UPSTREAM_HOST = '192.168.1.36';
const UPSTREAM_PORT = 80;
const PORT = 80;
const APP_ID = '828';

const MUSIC_PLAYER_IDS = new Set([
  '1074', '1075', '1076', '1077', '1078',
  '1079', '1080', '1081', '1082', '1083',
  '1085', '1086', '1087', '1088', '1089'
]);

function addMusicPlayer(capabilities) {
  if (Array.isArray(capabilities) && capabilities.includes('MusicPlayer') === false) {
    capabilities.push('MusicPlayer');
    return true;
  }
  return false;
}

function patchDevice(device) {
  if (!device || typeof device !== 'object') {
    return false;
  }

  if (MUSIC_PLAYER_IDS.has(String(device.id)) === false) {
    return false;
  }

  return addMusicPlayer(device.capabilities);
}

function patchResponse(pathname, body) {
  let data;

  try {
    data = JSON.parse(body.toString('utf8'));
  } catch (e) {
    return null;
  }

  const capabilityMatch = pathname.match(
    new RegExp('^/apps/api/' + APP_ID + '/devices/(\\d+)/capabilities/?$')
  );

  if (capabilityMatch) {
    const deviceId = capabilityMatch[1];

    if (MUSIC_PLAYER_IDS.has(deviceId) === false) {
      return null;
    }

    let changed = false;

    if (Array.isArray(data)) {
      for (const item of data) {
        if (item && Array.isArray(item.capabilities)) {
          changed = addMusicPlayer(item.capabilities) || changed;
        }
      }
    }

    return changed ? Buffer.from(JSON.stringify(data)) : null;
  }

  const deviceMatch = pathname.match(
    new RegExp('^/apps/api/' + APP_ID + '/devices/(\\d+)/?$')
  );

  if (deviceMatch) {
    return patchDevice(data) ? Buffer.from(JSON.stringify(data)) : null;
  }

  if (
    pathname.match(
      new RegExp('^/apps/api/' + APP_ID + '/devices/all/?$')
    )
  ) {
    let changed = false;

    if (Array.isArray(data)) {
      for (const device of data) {
        changed = patchDevice(device) || changed;
      }
    }

    return changed ? Buffer.from(JSON.stringify(data)) : null;
  }

  return null;
}

function makeHeaders(originalHeaders) {
  const headers = {
    ...originalHeaders,
    host: UPSTREAM_HOST,
    'accept-encoding': 'identity'
  };

  delete headers.connection;
  delete headers['content-length'];

  return headers;
}

const server = http.createServer((req, res) => {
  const incoming = new URL(req.url, 'http://localhost');

  const options = {
    hostname: UPSTREAM_HOST,
    port: UPSTREAM_PORT,
    path: incoming.pathname + incoming.search,
    method: req.method,
    headers: makeHeaders(req.headers)
  };

  const upstream = http.request(options, response => {
    const chunks = [];

    response.on('data', chunk => chunks.push(chunk));

    response.on('end', () => {
      const originalBody = Buffer.concat(chunks);
      const patchedBody = patchResponse(
        incoming.pathname,
        originalBody
      );

      const output = patchedBody || originalBody;
      const headers = {};

      for (const [key, value] of Object.entries(response.headers)) {
        if (
          key !== 'content-length' &&
          key !== 'transfer-encoding' &&
          key !== 'content-encoding' &&
          key !== 'connection'
        ) {
          headers[key] = value;
        }
      }

      headers['content-length'] = output.length;

      if (patchedBody) {
        headers['content-type'] = 'application/json';

        console.log(
          '[HD+ Proxy] Added MusicPlayer: ' +
          incoming.pathname
        );
      }

      res.writeHead(response.statusCode || 502, headers);
      res.end(output);
    });
  });

  upstream.on('error', err => {
    console.error(
      '[HD+ Proxy] HTTP upstream error: ' +
      err.message
    );

    res.writeHead(502, {
      'Content-Type': 'text/plain'
    });

    res.end('Hubitat upstream error: ' + err.message);
  });

  req.pipe(upstream);
});

server.on('upgrade', (req, clientSocket, head) => {
  const incoming = new URL(req.url, 'http://localhost');

  const options = {
    hostname: UPSTREAM_HOST,
    port: UPSTREAM_PORT,
    path: incoming.pathname + incoming.search,
    method: 'GET',
    headers: {
      ...req.headers,
      host: UPSTREAM_HOST
    }
  };

  const upstream = http.request(options);

  upstream.on('upgrade', (response, upstreamSocket, upstreamHead) => {
    let responseText =
      'HTTP/' +
      response.httpVersion +
      ' ' +
      response.statusCode +
      ' ' +
      response.statusMessage +
      '\r\n';

    for (const [key, value] of Object.entries(response.headers)) {
      if (Array.isArray(value)) {
        for (const item of value) {
          responseText += key + ': ' + item + '\r\n';
        }
      } else {
        responseText += key + ': ' + value + '\r\n';
      }
    }

    responseText += '\r\n';

    clientSocket.write(responseText);

    if (upstreamHead.length > 0) {
      clientSocket.write(upstreamHead);
    }

    if (head.length > 0) {
      upstreamSocket.write(head);
    }

    upstreamSocket.pipe(clientSocket);
    clientSocket.pipe(upstreamSocket);

    console.log(
      '[HD+ Proxy] WebSocket upgrade: ' +
      incoming.pathname
    );
  });

  upstream.on('response', response => {
    response.resume();
    clientSocket.destroy();
  });

  upstream.on('error', err => {
    console.error(
      '[HD+ Proxy] WebSocket error: ' +
      err.message
    );

    clientSocket.destroy();
  });

  upstream.end();
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(
    '[HD+ Proxy] Listening on port ' +
    PORT
  );

  console.log(
    '[HD+ Proxy] Forwarding all traffic to http://' +
    UPSTREAM_HOST
  );

  console.log(
    '[HD+ Proxy] MusicPlayer injection enabled for ' +
    MUSIC_PLAYER_IDS.size +
    ' devices'
  );
});

const httpsForwarder = net.createServer(clientSocket => {
  const upstreamSocket = net.connect(
    443,
    UPSTREAM_HOST,
    () => {
      clientSocket.pipe(upstreamSocket);
      upstreamSocket.pipe(clientSocket);
    }
  );

  upstreamSocket.on('error', err => {
    console.error(
      '[HD+ Proxy] HTTPS forward error: ' +
      err.message
    );

    clientSocket.destroy();
  });

  clientSocket.on('error', err => {
    console.error(
      '[HD+ Proxy] HTTPS client error: ' +
      err.message
    );

    upstreamSocket.destroy();
  });
});

httpsForwarder.listen(443, '0.0.0.0', () => {
  console.log(
    '[HD+ Proxy] HTTPS passthrough listening on port 443'
  );

  console.log(
    '[HD+ Proxy] HTTPS passthrough forwarding to https://' +
    UPSTREAM_HOST + ':443'
  );
});
