## Cleanup — HD+ proxy and Plex diagnostic removal (2026-10-29)

- Removed the HD+ proxy launch from `start.sh`.
- Removed published ports 80 and 443 from the main Echos Speak Compose configuration.
- Removed the abandoned `/debug/audioplayer-test` Plex diagnostic route.
- Preserved ports 4000 and 4001, normal command handling, timeout settings, and persistent data.
- The separate `hdplus-proxy` and `echos-speak-plex-bridge` folders are backed up and removed by the deployment script only after the main service rebuild succeeds.
- No timeout or voiceAsText behavior changes.

# Echos Speak Advanced Server

## v1.3.3

- Fixed the non-WHA `play`/`pause` verification result path by removing a call to the undefined `_extractPlaybackMetadata()` helper.
- Restored the existing playback result construction used by the known-good implementation.
- Preserved WHA routing, Alexa command dispatch, verification polling, timeouts, and all other command behavior.

## v1.3.2

- Corrected WHA `speak` and `speak`-with-voice routing to dispatch the sequence individually to every physical `clusterMember` because `alexa-remote2` v8.1.1 does not expand an array target into independent device substitutions for `sendSequenceCommand()`.
- Waits for all WHA member dispatch callbacks before completing the single bridge command; reports the first member error if any member fails.
- Preserved ordinary-device `speak` behavior and the existing WHA `announce` implementation.

## v1.3.1

- Corrected WHA `speak` routing so speech is expanded from the WHA virtual endpoint to its physical `clusterMembers`, reusing the established WHA member-routing pattern already used by `announce`.
- Applied the same physical-member routing to `speak` with and without the optional SSML voice path.
- Preserved ordinary-device `speak` behavior and all existing command, timeout, logging, and capability behavior.


## v1.3.0

- Hardened expensive read operations against duplicate concurrent requests for the same device.
- Coalesced concurrent `getDeviceFeatures` requests per serial number so only one Amazon feature/state query is in flight at a time; all callers receive the same completed result.
- Coalesced concurrent `getPlaybackState` requests per serial number to prevent duplicate `getPlayerInfo()` calls when Hubitat refresh paths overlap.
- Replaced recursive traversal of Amazon smart-home payloads with iterative stack-based traversal to remove call-stack depth risk on unexpectedly deep payloads.
- Replaced recursive traversal of returned sensor capability states with iterative traversal for the same reason.
- Corrected WHA audio-notification family comparison fallback typo.
- Preserved existing command behavior, capability mapping, timeouts, and Amazon API usage.


## v1.2.7

- Added `mute` and `unmute` bridge commands.
- `mute` uses the existing supported Alexa Device Controls volume sequence and sets volume to 0.
- `unmute` restores the volume level supplied by the Hubitat child driver.
- No undocumented/direct Alexa mute sequence is assumed.
- Preserved the existing dispatcher timeout, result validation, and command logging.


## v1.2.6

- Added Fire TV video-control test commands: `fireTVPauseVideo`, `fireTVResumeVideo`, `fireTVStartVideo`, and `fireTVStopVideo`.
- `fireTVPauseVideo` maps to `Alexa.Operation.FireTV.PauseVideo` through the authenticated Alexa Fire TV routine sequence path.
- `fireTVResumeVideo` and `fireTVStartVideo` map to `Alexa.Operation.FireTV.ResumeVideo` (Start is an explicit test alias for Resume).
- `fireTVStopVideo` uses the existing `deviceStop` sequence as a separate stop test; it is not aliased to Pause.
- Fire TV test commands require `deviceFamily == FIRE_TV` and a valid `deviceAccountId`.
- Preserved the existing 15-second timeout, Alexa result validation, and command lifecycle logging.

## v1.2.1

- Corrected Alexa result handling so application-level failures such as `No routes found` are not reported as successful commands.
- Added target diagnostics to command logs: device family/type, online state, controllability, music-player state, and capabilities.
- Extended `/api/devices` with non-sensitive capability/route metadata for troubleshooting.
- Corrected Amazon announcement content locale to `en-US` for the `amazon.com` deployment instead of relying on alexa-remote2 v8.1.1's hard-coded `de-DE` announcement locale.
- Kept the proper `AlexaAnnouncement` target structure and device serial/type identifiers.
- Preserved the corrected `sendCommand(serialOrName, command, value, callback)` contract.
- `ALEXA_COMMAND_FAILED` now returns HTTP 502 so callers can distinguish an Alexa rejection from a malformed bridge request.

## v1.2.0

- Corrected `alexa-remote2` v8.1.1 `sendCommand()` callback argument order for `play`, `pause`, `nextTrack`, and `previousTrack`.
- Kept `sendSequenceCommand()` mappings aligned with the v8.1.1 callback contract.
- Reworked `announceAll` to use the library-supported array target form and the same VOX exclusion used by discovery.
- Preserved the 15-second dispatcher timeout and command lifecycle logging for diagnostic visibility.
- Preserved proper `deviceStop` behavior; Stop is not aliased to Pause.
- Preserved raw sequence command support while retaining explicit `rawPayload` values such as `false` or `0`.
- Tightened volume validation to require an integer from 0 through 100.

## Deployment

The archive is intended to replace the server project files (except the persistent `data/session.json`).
After extraction into `/volume1/docker/echos-speak`, rebuild the image so the source changes are included.
