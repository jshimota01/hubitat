const fs = require('fs');
const path = require('path');
const axios = require('axios');

const CONFIG_FILE = path.join(__dirname, '../data/config.json');

class PlexClient {
  constructor() {
    this.config = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'));
  }

  get headers() {
    return {
      'X-Plex-Token': this.config.plexToken,
      'Accept': 'application/json'
    };
  }

  async getServerInfo() {
    const response = await axios.get(`${this.config.plexUrl}/`, {
      headers: this.headers
    });

    return response.data.MediaContainer;
  }

  async getLibraries() {
    const response = await axios.get(
      `${this.config.plexUrl}/library/sections`,
      { headers: this.headers }
    );

    return response.data.MediaContainer.Directory || [];
  }

  async getMusicArtists() {
    const response = await axios.get(
      `${this.config.plexUrl}/library/sections/3/all`,
      {
        headers: this.headers,
        params: {
          type: 8,
          limit: 20
        }
      }
    );

    return response.data.MediaContainer;
  }
}

module.exports = new PlexClient();
