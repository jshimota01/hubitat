const express = require('express');
const plexClient = require('./plexClient');

const app = express();
const PORT = process.env.PORT || 4100;

app.use(express.json());

app.get('/health', (req, res) => {
  res.json({
    success: true,
    service: 'echos-speak-plex-bridge',
    status: 'running'
  });
});

app.get('/plex/status', async (req, res) => {
  try {
    const plex = await plexClient.getServerInfo();
    res.json({ success: true, server: plex });
  } catch (err) {
    console.error('Plex status failed:', err.message);
    res.status(500).json({ success: false, error: err.message });
  }
});

app.get('/plex/libraries', async (req, res) => {
  try {
    const libraries = await plexClient.getLibraries();
    res.json({ success: true, libraries });
  } catch (err) {
    console.error('Plex libraries failed:', err.message);
    res.status(500).json({ success: false, error: err.message });
  }
});

app.get('/plex/music/artists', async (req, res) => {
  try {
    const artists = await plexClient.getMusicArtists();
    res.json({ success: true, artists });
  } catch (err) {
    console.error('Plex music artists failed:', err.message);
    res.status(500).json({ success: false, error: err.message });
  }
});

app.listen(PORT, () => {
  console.log(`Echos Speak Plex Bridge running on port ${PORT}`);
});
