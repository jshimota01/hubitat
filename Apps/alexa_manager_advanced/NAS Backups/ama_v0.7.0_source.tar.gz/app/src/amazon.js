import AlexaRemote from 'alexa-remote2';
import { mkdir, readFile, writeFile, rename } from 'node:fs/promises';
import { dirname } from 'node:path';
import { config } from './config.js';
import { log } from './logger.js';

let remote = null;
let state = {
  status: 'NOT_CONFIGURED',
  authenticated: false,
  lastInventoryAt: null,
  inventoryCount: 0,
  lastError: null,
  proxyStartedAt: null
};
let inventory = [];
let operation = Promise.resolve();

async function readJson(path, fallback) {
  try { return JSON.parse(await readFile(path, 'utf8')); }
  catch (error) { if (error.code === 'ENOENT') return fallback; throw error; }
}
async function writeJson(path, value) {
  await mkdir(dirname(path), { recursive: true });
  const temp = `${path}.tmp`;
  await writeFile(temp, JSON.stringify(value, null, 2), { mode: 0o600 });
  await rename(temp, path);
}
async function saveSession(cookieData) {
  if (!cookieData) return;
  await writeJson(config.amazonDataFile, { cookie: cookieData, updatedAt: new Date().toISOString() });
}
function callRemote(method) {
  return new Promise((resolve, reject) => {
    if (!remote || typeof remote[method] !== 'function') return reject(new Error(`Amazon client method unavailable: ${method}`));
    remote[method]((error, result) => error ? reject(error) : resolve(result));
  });
}
function safeInventoryItem(item, index) {
  const source = item && typeof item === 'object' ? item : { value: item };
  return {
    index,
    entityId: source.entityId ?? source.id ?? source.applianceId ?? null,
    entityType: source.entityType ?? source.type ?? null,
    name: source.name ?? source.friendlyName ?? source.displayName ?? null,
    manufacturer: source.manufacturer ?? null,
    model: source.model ?? null,
    capabilities: Array.isArray(source.capabilities) ? source.capabilities : [],
    properties: Array.isArray(source.properties) ? source.properties : [],
    raw: source
  };
}
export function amazonStatus() {
  return {
    ...state,
    proxyPort: config.amazonProxyPort,
    proxyOwnIp: config.amazonProxyOwnIp
  };
}
function initializeRemote(cookie = undefined) {
  if (remote) return;
  remote = new AlexaRemote();
  remote.on('cookie', async () => {
    try { await saveSession(remote.cookieData); }
    catch (error) { state.lastError = String(error?.message || error); log('error', 'Could not persist Amazon session', { message: state.lastError }); }
  });
  const options = {
    proxyOnly: !cookie,
    proxyOwnIp: config.amazonProxyOwnIp,
    proxyPort: config.amazonProxyPort,
    proxyLogLevel: 'info',
    alexaServiceHost: config.amazonServiceHost,
    usePushConnection: false,
    cookieRefreshInterval: 7 * 24 * 60 * 60 * 1000,
    ...(cookie ? { cookie } : {})
  };
  remote.init(options, async error => {
    if (error) {
      const message = String(error.message || error);
      if (!cookie && /please open|proxy/i.test(message)) {
        state.status = 'LOGIN_REQUIRED';
        state.proxyStartedAt = new Date().toISOString();
        state.lastError = null;
        log('info', 'Amazon login proxy is ready', { proxyPort: config.amazonProxyPort });
        return;
      }
      state.status = 'ERROR';
      state.authenticated = false;
      state.lastError = message.slice(0, 400);
      log('warn', 'Amazon authentication initialization failed', { message: state.lastError });
      return;
    }
    state.authenticated = true;
    state.status = 'AUTHENTICATED';
    state.lastError = null;
    try { await saveSession(remote.cookieData); } catch (saveError) {
      state.lastError = String(saveError?.message || saveError).slice(0, 400);
    }
    log('info', 'Amazon account authentication established');
  });
}
export async function loadAmazonState() {
  const savedInventory = await readJson(config.amazonInventoryFile, { devices: [], retrievedAt: null });
  inventory = Array.isArray(savedInventory.devices) ? savedInventory.devices : [];
  if (inventory.length) {
    state.inventoryCount = inventory.length;
    state.lastInventoryAt = savedInventory.retrievedAt || null;
  }
  const savedSession = await readJson(config.amazonDataFile, null);
  if (savedSession?.cookie) {
    state.status = 'SESSION_SAVED';
    initializeRemote(savedSession.cookie);
  }
}
export function startAmazonLogin() {
  const task = operation.then(async () => {
    if (remote && state.status === 'ERROR') {
      try { remote.stop(); } catch {}
      remote = null;
    }
    if (remote) return { started: true, status: state.status, proxyUrl: `http://${config.amazonProxyOwnIp}:${config.amazonProxyPort}` };
    initializeRemote();
    return { started: true, status: 'LOGIN_REQUIRED', proxyUrl: `http://${config.amazonProxyOwnIp}:${config.amazonProxyPort}` };
  });
  operation = task.catch(() => {});
  return task;
}
export async function refreshAmazonInventory() {
  if (!remote || !state.authenticated) throw new Error('Amazon account is not authenticated. Start Amazon login first.');
  const result = await callRemote('getSmarthomeDevicesV2');
  const rows = Array.isArray(result) ? result
    : Array.isArray(result?.devices) ? result.devices
    : Array.isArray(result?.appliances) ? result.appliances
    : Array.isArray(result?.entities) ? result.entities
    : Array.isArray(result?.smarthomeDevices) ? result.smarthomeDevices
    : null;
  if (!rows) throw new Error('Amazon returned an unrecognized Smart Home inventory response; cached inventory was preserved.');
  const next = rows.map(safeInventoryItem);
  const retrievedAt = new Date().toISOString();
  await writeJson(config.amazonInventoryFile, { retrievedAt, devices: next });
  inventory = next;
  state.lastInventoryAt = retrievedAt;
  state.inventoryCount = next.length;
  state.lastError = null;
  state.status = 'AUTHENTICATED';
  return { retrievedAt, count: next.length, devices: next };
}
export function getAmazonInventory() {
  return { retrievedAt: state.lastInventoryAt, count: inventory.length, devices: inventory };
}
