# Alexa Manager Advanced — NAS Service

**Package version: 0.6.0**  
**Service address: `http://192.168.1.23:4100`**  
**Hubitat platform:** local Hubitat C-7 integration  
**InfluxDB address:** `http://192.168.1.12:8086` (separate service; do not confuse this with the AMA NAS address)

AMA NAS is a standalone local service and remains completely separate from Echos Speak. Hubitat remains the source of truth for device state and commands.

## Version 0.6.0 changes

- Adds authenticated NAS/InfluxDB monitoring status for the Hubitat AMA System Monitor.
- Checks InfluxDB reachability through its `/health` endpoint independently of telemetry write enablement.
- Tracks Hubitat heartbeat receipt and successful InfluxDB heartbeat writes.
- Logs the application version, environment, and startup timestamp at INFO level on every startup.

## Previous version 0.5.3 changes

- Corrects `src/config.js` so the runtime-reported `appVersion` is `0.5.3`, matching `package.json`, this README, and the changelog.
- Documents the actual NAS bind address and Hubitat base URL: `192.168.1.23:4100`.
- Includes the `data/` directory as a versioned data snapshot, including the device registry and OAuth store present when this package was assembled.
- Clarifies the difference between the packaged data snapshot and the live data on the NAS during an update.
- Excludes the live `.env` file from the archive. Use `.env.example` as a template and retain the NAS's existing `.env` separately.

## What is in this archive

The ZIP contents begin directly at the application root; there is no additional enclosing version folder.

- Application source under `src/`, including the Hubitat event ingestion endpoint.
- `package.json`, `Dockerfile`, `docker-compose.yml`, and `.dockerignore`.
- `test/` and the release changelog.
- `data/devices.json` and `data/oauth-store.json` as the versioned snapshot accompanying this release.
- `.env.example` as the configuration template.
- Reverse-proxy reference backups. These are reference files, not automatic deployment instructions.

The archive intentionally does **not** include `.env`, because it contains live API keys, OAuth credentials, and InfluxDB tokens. The data snapshot does include OAuth token-store contents and must be treated as sensitive. Keep the archive in private, access-controlled storage; do not publish it or place it in a public source repository.

## Updating the existing Synology NAS installation

1. Back up the current AMA project directory, including its `.env` and `data/` directory.
2. Extract this release to a staging directory and review the files before copying them into the live project.
3. Copy the application source, package metadata, Dockerfile, and documentation into the existing project directory.
4. Keep the existing live `.env`. Do not replace it with `.env.example`; use `.env.example` only to identify newly introduced settings.
5. The archive includes a point-in-time `data/` snapshot for version control and recovery. **Do not blindly overwrite the live `data/` directory during a routine upgrade.** Preserve the live OAuth store and device registry unless you deliberately intend to restore the packaged snapshot. If restoring, stop the service first and make a separate backup of the current live data.
6. Review `docker-compose.yml` and retain the intended local bind address `192.168.1.23:4100`.
7. Rebuild and recreate the existing container using the normal project deployment procedure. Do not create a second container or change the existing container identity.
8. Verify `GET /api/health` and `GET /api/v1/status`; both should report application version `0.6.0`.

The package contains data so the release is reproducible and recoverable. The update procedure preserves live data so an ordinary source update cannot roll back current OAuth sessions or device registrations. These are complementary rules, not a contradiction.

## Hubitat configuration

Set the AMA NAS Base URL in the Hubitat Parent application to:

`http://192.168.1.23:4100`

Use the existing AMA API key from the NAS `.env` file. Do not put that key into source code or the archive. The Hubitat app uses Hubitat's local app endpoint and access token for callbacks; do not forward that endpoint through the router or expose it to the internet.

## Network addresses

| Service | Address | Purpose |
|---|---|---|
| AMA NAS | `192.168.1.23:4100` | AMA service; Docker host bind |
| InfluxDB | `192.168.1.12:8086` | Separate InfluxDB service |
| Hubitat | Local Hubitat C-7 address | Hubitat device state and command authority |

The InfluxDB URL remains `http://192.168.1.12:8086`; that address is correct for InfluxDB and is not the AMA NAS service address.

## API changes

All `/api/v1/*` routes require `Authorization: Bearer <AMA_API_KEY>`.

- `POST /api/v1/telemetry/hubitat-event` accepts parent-forwarded Hubitat events and the periodic `hubitat.heartbeat` event.
- The NAS normalizes known device properties into InfluxDB tags/fields and retains the original event payload for normal device events.
- `GET /api/v1/monitoring/status` returns the authenticated monitoring snapshot consumed by Hubitat's AMA System Monitor.
- `GET /api/v1/telemetry/status` reports current telemetry configuration and in-memory write status.
- `POST /api/v1/telemetry/test` performs an explicit test write independently of continuous telemetry enablement.

## NAS telemetry configuration

The NAS service writes directly to InfluxDB 2.x. It does not route telemetry through Hubitat.

Configure these variables in the existing NAS `.env` file:

- `INFLUX_ENABLED=false` unless continuous NAS telemetry is intentionally enabled.
- `INFLUX_URL=http://192.168.1.12:8086`
- `INFLUX_ORG=DundeeHome`
- `INFLUX_BUCKET=HubAlexa`
- `INFLUX_TOKEN=` the existing NAS writer token.

The InfluxDB reachability check is independent of `INFLUX_ENABLED`: when `INFLUX_URL` is configured, the monitoring endpoint requests InfluxDB's `/health` endpoint. Continuous telemetry writes and heartbeat writes still require `INFLUX_ENABLED=true`.

## Hubitat companion code

The matching Hubitat release files are delivered separately: Parent v0.7.7, Monitoring & Analytics v0.2.5, and the `AMA System Monitor` device driver v1.0.0. Install the device driver before saving/updating the Monitoring & Analytics child so it can create its single child device.

## Hubitat monitoring behavior (0.6.0)

- The Monitoring & Analytics child sends a heartbeat every five minutes through the Parent's existing authenticated NAS connection.
- The heartbeat is sent even when ordinary Hubitat event telemetry is disabled, so NAS receipt can still confirm Hubitat-to-NAS connectivity.
- The NAS records the last heartbeat received in memory and, when `INFLUX_ENABLED=true`, writes a separate `hubitat_heartbeat` measurement.
- The monitoring API distinguishes NAS availability, InfluxDB reachability, Hubitat heartbeat receipt, and successful heartbeat storage in InfluxDB.
- Hubitat polls the authenticated monitoring API through the Parent after each heartbeat and updates one `AMA System Monitor` virtual device.
- NAS event/heartbeat counters and InfluxDB write counters are process-lifetime counters; they reset when the NAS service restarts. The last successful heartbeat write is tracked separately from ordinary writes.

## Startup logging

Every NAS service start prints an INFO-level structured log entry containing the application name, version from `src/config.js`, environment, and startup timestamp. This is unconditional with respect to warning/error conditions.

## Testing

Run:

```sh
npm run check
npm test
```

After deployment, verify `/api/health` reports version `0.6.0`, then verify the authenticated `/api/v1/monitoring/status` endpoint through the Parent/Monitoring child.
