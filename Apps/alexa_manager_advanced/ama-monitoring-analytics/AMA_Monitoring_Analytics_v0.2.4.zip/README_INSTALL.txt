AMA Monitoring & Analytics v0.2.4

Complete Hubitat event payloads travel through the Parent to the AMA NAS.
The Parent owns the NAS URL and API key. The NAS normalizes event properties for
InfluxDB and retains the complete received JSON event envelope.

Continuous forwarding is controlled by the existing 'Enable Hubitat telemetry
reporting' setting. The existing InfluxDB settings and Test button remain for
direct connection diagnostics, but parent event telemetry is sent to the NAS.

Install after NAS v0.5.2 and Parent v0.7.5:
1. Replace the Monitoring & Analytics child app code with the included Groovy file.
2. Save and update the installed child app.
3. Confirm 'Enable Hubitat telemetry reporting' remains enabled.
4. Toggle Bathroom Fan and inspect NAS measurement `ama_nas`, event `hubitat_event`.
