## 0.5.1 — 2026-11-10
- Added the Alexa directive endpoint ID as an InfluxDB tag when the directive targets a specific endpoint, allowing device-specific directive queries (for example, `hubitat-558`).
- Kept discovery directives endpoint-agnostic because Alexa Discovery requests do not contain a target endpoint ID.
- Updated service/API version reporting to use the configured application version.

## 0.5.0 — 2026-11-10
- Added direct NAS-to-InfluxDB 2.x telemetry using a dedicated NAS token.
- Added independent telemetry enable/configuration environment variables.
- Added authenticated telemetry status and test-write API endpoints; test writes work while continuous telemetry is disabled.
- Added non-blocking telemetry for service startup, Hubitat device registration/state updates, and Alexa directive outcomes.
- Telemetry failures are logged and isolated from Alexa/Hubitat request handling.

# Changelog

## 0.4.0 — 2026-11-04
- Added Hubitat switch registration/upsert API.
- Added Hubitat switch state synchronization API.
- Added NAS-to-Hubitat command callback client for TurnOn/TurnOff.
- Alexa PowerController now routes Hubitat-backed devices to their local Hubitat app endpoint while retaining local simulation behavior.
- Added Hubitat parent app source for selecting switches, registration, event subscription, state reporting, and command callbacks.
- Preserved OAuth, token store, existing simulated test device behavior, and independent Echos Speak isolation.

## 0.3.0 — 2026-11-04
- Added Alexa Smart Home API v3 Discovery, PowerController, and StateReport.
- Added persistent device registry and local simulation backend.
