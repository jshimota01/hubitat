# Alexa Manager Advanced — NAS Service

**Package version: 0.7.3**  
**Service address: `http://192.168.1.23:4100`**  
**Amazon login proxy: `http://192.168.1.23:3456`**  
**Hubitat platform:** local Hubitat C-7 integration  
**InfluxDB:** `http://192.168.1.12:8086`, organization `DundeeHome`, bucket `HubAlexa`

AMA NAS is a standalone local service, separate from Echos Speak. Hubitat remains the source of truth for device state and commands. The NAS service provides the Alexa-facing API, Amazon household inventory integration, OAuth endpoints, telemetry intake, and monitoring endpoints.

## Version 0.7.3

This release is a documentation and version-consistency update over v0.7.2:

- Aligns `src/config.js` runtime version with `package.json` and the release changelog.
- Updates the README and deployment instructions to describe the current service rather than the original v0.7.0 feature set.
- Documents the current InfluxDB destination and existing telemetry/test-write behavior.
- Does not change API behavior, Amazon authentication, OAuth, API-key authentication, InfluxDB writes, or persistent data formats.

## Archive contents and backup model

The project archive is a complete working backup snapshot. It includes the application source, build files, documentation, `.env`, and the point-in-time `data/` files supplied with the backup. The `.env` file contains the deployment's configured API, OAuth, and InfluxDB settings. The `data/` directory contains the saved Amazon session, Amazon inventory cache, device registry, and OAuth store.

The archive is intended for the owner's private backup, recovery, and development workflow. When deploying a source-only update over an existing installation, preserve the live `.env` and `data/` directory unless restoring the archive's snapshot is intentional. When performing a full restore, restore the matching `.env` and `data/` snapshot together with the application files.

## NAS service layout

- `src/`: Express service, API routes, Amazon integration, OAuth handling, device registry, Hubitat client, and InfluxDB telemetry writer.
- `scripts/`: install-time compatibility patch for `alexa-cookie2`.
- `test/`: automated Node.js tests.
- `data/`: persistent runtime state and backup snapshot.
- `package.json` / `package-lock.json`: package metadata and locked dependencies.
- `Dockerfile` / `docker-compose.yml`: container build and local service deployment.
- `.env`: deployment environment settings.
- `CHANGELOG.md`: release history.

## Network endpoints

| Service | Address | Purpose |
|---|---|---|
| AMA NAS | `192.168.1.23:4100` | Main AMA service, bound to the NAS LAN address |
| Amazon login proxy | `192.168.1.23:3456` | Local Amazon sign-in proxy |
| InfluxDB | `192.168.1.12:8086` | AMA telemetry storage |
| Hubitat | Local Hubitat C-7 address | Device state and command authority |

The InfluxDB address is intentionally different from the AMA NAS address.

## Amazon household inventory

The Amazon household inventory integration is read-only. It retrieves the household Smart Home inventory through `alexa-remote2` 8.1.1 and `getSmarthomeDevicesV2()`; it does not change device exposure.

- `POST /api/v1/amazon/login/start` starts the local login proxy workflow.
- Open `http://192.168.1.23:3456` from the local network and complete Amazon sign-in.
- `GET /api/v1/amazon/status` reports authentication and inventory state.
- `POST /api/v1/amazon/inventory/refresh` refreshes the household inventory.
- `GET /api/v1/amazon/inventory` returns the cached inventory.

The Amazon session and inventory cache are stored separately in `data/amazon-session.json` and `data/amazon-inventory.json`.

## API overview

All `/api/v1/*` routes require the AMA API key in the HTTP Bearer authorization header.

| Endpoint | Purpose |
|---|---|
| `GET /api/health` | Unauthenticated service health and version |
| `GET /api/v1/status` | Authenticated service, device, telemetry, and Amazon status |
| `POST /api/v1/telemetry/hubitat-event` | Receives Parent-forwarded Hubitat events and heartbeat events |
| `GET /api/v1/telemetry/status` | Reports telemetry configuration and in-memory write status |
| `POST /api/v1/telemetry/test` | Performs an explicit InfluxDB test write |
| `GET /api/v1/monitoring/status` | Monitoring snapshot consumed by the Hubitat AMA System Monitor |
| `GET /api/v1/amazon/status` | Amazon authentication and inventory status |
| `POST /api/v1/amazon/login/start` | Starts Amazon login |
| `GET /api/v1/amazon/inventory` | Returns cached Amazon household inventory |
| `POST /api/v1/amazon/inventory/refresh` | Refreshes Amazon household inventory |

The remaining `/api/v1/devices*` and `/api/v1/alexa/directive` endpoints support device registration/state synchronization and Alexa Smart Home directives.

## InfluxDB telemetry

AMA NAS writes its telemetry directly to InfluxDB 2.x. The configured AMA destination is:

- URL: `http://192.168.1.12:8086`
- Organization: `DundeeHome`
- Bucket: `HubAlexa`

The active `.env` supplies `INFLUX_URL`, `INFLUX_ORG`, `INFLUX_BUCKET`, and `INFLUX_TOKEN`. `INFLUX_ENABLED=true` enables continuous telemetry and heartbeat writes. When continuous telemetry is disabled, the InfluxDB `/health` reachability check remains available, and the explicit `POST /api/v1/telemetry/test` diagnostic endpoint can still perform a test write. The test endpoint is intentionally separate from continuous reporting.

Hubitat event and heartbeat intake is handled by the NAS. The Parent sends the event envelope; the NAS normalizes it into AMA telemetry measurements. The NAS monitoring API reports InfluxDB reachability, write status, successful writes, failures, and Hubitat heartbeat receipt/storage information.

## Hubitat integration and monitoring

The Hubitat Parent application uses the AMA NAS Base URL:

`http://192.168.1.23:4100`

The Parent sends authenticated device/telemetry requests to the NAS and handles callbacks locally. The Monitoring & Analytics child uses the Parent for NAS communication and updates the AMA System Monitor virtual device from the monitoring snapshot.

The heartbeat is sent every five minutes through the Parent's authenticated NAS connection. NAS receipt confirms Hubitat-to-NAS connectivity. When `INFLUX_ENABLED=true`, the NAS also writes a separate `hubitat_heartbeat` measurement. Monitoring distinguishes NAS availability, InfluxDB reachability, heartbeat receipt, and successful heartbeat storage.

NAS event/heartbeat counters are process-lifetime counters and reset when the service restarts. The last successful heartbeat write is tracked separately from ordinary telemetry writes.

## Deployment update

Project directory on the Synology NAS:

`/volume1/docker/alexa-manager-advanced`

For a normal source update:

1. Extract the release archive to a staging directory and review the files.
2. Back up the current project directory.
3. Copy the updated application source, package files, Dockerfile, scripts, and documentation into the project directory.
4. Keep the live `.env` and `data/` directory in place so current deployment settings, Amazon session, inventory, device registry, and OAuth state remain intact.
5. Retain the existing `docker-compose.yml` and its container name, port mappings, and volume mapping unless the release specifically changes them.
6. Rebuild and recreate the existing service using the commands below.

For a full restore from a complete backup, restore the archive's `.env` and `data/` snapshot along with the application files. The source-update and full-restore procedures serve different purposes.

Run from the project directory:

```sh
sudo docker compose down
sudo docker compose build --no-cache
sudo docker compose up -d
sudo docker compose ps
curl -s http://192.168.1.23:4100/api/health
sudo docker compose logs --tail=30
```

A successful health response should report version `0.7.3`. Startup logs also report the runtime version and startup timestamp.

## Verification

From the project directory, run:

```sh
npm run check
npm test
```

After deployment, verify:

- `GET http://192.168.1.23:4100/api/health` reports `version: 0.7.3`.
- `GET /api/v1/status` reports the expected device, telemetry, and Amazon state.
- `GET /api/v1/monitoring/status` returns the monitoring snapshot consumed by Hubitat.
- Amazon status reports the expected authentication state and inventory count.

The Docker build installs the dependencies from `package-lock.json` and runs the `alexa-cookie2` compatibility patch through the package postinstall script.
