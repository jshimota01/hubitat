import test from 'node:test';
import assert from 'node:assert/strict';

// The Amazon client is initialized only by explicit login or a saved session.
// These tests verify the module's exported status shape without making network calls.
process.env.NODE_ENV = 'test';
const amazon = await import('../src/amazon.js');

test('Amazon status starts without claiming an authenticated session', () => {
  const status = amazon.amazonStatus();
  assert.equal(typeof status.status, 'string');
  assert.equal(status.authenticated, false);
  assert.equal(status.inventoryCount, 0);
});

test('Amazon inventory starts as an empty cached snapshot', () => {
  const snapshot = amazon.getAmazonInventory();
  assert.equal(snapshot.count, 0);
  assert.deepEqual(snapshot.devices, []);
});
