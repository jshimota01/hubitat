import test, { after } from 'node:test';
import assert from 'node:assert/strict';

process.env.INFLUX_ENABLED = 'true';
process.env.INFLUX_URL = 'http://influx.test:8086';
process.env.INFLUX_ORG = 'DundeeHome';
process.env.INFLUX_BUCKET = 'HubAlexa';
process.env.INFLUX_TOKEN = 'monitoring-test-token';
process.env.NODE_ENV = 'test';

const originalFetch = globalThis.fetch;
const requests = [];
globalThis.fetch = async (url, options = {}) => {
  requests.push({ url: String(url), method: options.method || 'GET', body: options.body });
  if (String(url).endsWith('/health')) {
    return { ok: true, status: 200, text: async () => '{"status":"pass"}' };
  }
  return { ok: true, status: 204, text: async () => '' };
};

const { checkInfluxHealth, influxStatus, recordTelemetry } = await import('../src/influx.js');

after(() => { globalThis.fetch = originalFetch; });

test('InfluxDB health probe reports reachability independently of write status', async () => {
  const status = await checkInfluxHealth();
  assert.equal(status.healthStatus, 'HEALTHY');
  assert.ok(status.lastHealthCheckAt);
  assert.equal(requests[0].url, 'http://influx.test:8086/health');
});

test('successful Hubitat heartbeat write is separately timestamped', async () => {
  recordTelemetry('hubitat_heartbeat', { monitoring_version: '0.2.5' }, { origin: 'hubitat' });
  for (let attempt = 0; attempt < 30 && !influxStatus().lastHubitatHeartbeatWriteAt; attempt += 1) {
    await new Promise(resolve => setTimeout(resolve, 10));
  }
  const status = influxStatus();
  assert.ok(status.lastHubitatHeartbeatWriteAt);
  assert.ok(status.lastWriteAt);
  const write = requests.find(item => item.method === 'POST');
  assert.ok(write);
  assert.match(write.body, /hubitat_heartbeat/);
});
