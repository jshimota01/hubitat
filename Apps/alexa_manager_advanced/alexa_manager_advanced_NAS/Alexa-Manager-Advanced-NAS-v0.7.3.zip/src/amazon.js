import AlexaRemote from 'alexa-remote2';
import { mkdir, readFile, writeFile, rename } from 'node:fs/promises';
import { dirname } from 'node:path';
import { config } from './config.js';
import { log } from './logger.js';

const STATES = Object.freeze({
  UNINITIALIZED: 'UNINITIALIZED',
  VALIDATING: 'VALIDATING',
  AUTHENTICATING: 'AUTHENTICATING',
  AUTHENTICATED: 'AUTHENTICATED',
  AUTH_REQUIRED: 'AUTH_REQUIRED',
  DEGRADED: 'DEGRADED',
  ERROR: 'ERROR'
});

let remote = null;
let state = {
  status: STATES.UNINITIALIZED,
  authenticated: false,
  lastInventoryAt: null,
  inventoryCount: 0,
  lastError: null,
  proxyStartedAt: null,
  lastValidatedAt: null,
  sessionSavedAt: null
};
let inventory = [];
let operation = Promise.resolve();
let watchdog = null;
let validationInProgress = false;

async function readJson(path, fallback) {
  try { return JSON.parse(await readFile(path, 'utf8')); }
  catch (error) { if (error.code === 'ENOENT') return fallback; throw error; }
}

async function writeJson(path, value) {
  await mkdir(dirname(path), { recursive: true });
  const temp = `${path}.tmp`;
  await writeFile(temp, JSON.stringify(value, null, 2), { mode: 0o600 });
  await rename(temp, path);
}

function transition(status, reason = '') {
  const previous = state.status;
  state.status = status;
  state.authenticated = status === STATES.AUTHENTICATED;
  log('info', `Amazon authentication state: ${previous} -> ${status}${reason ? ` (${reason})` : ''}`);
}

function proxyUrl() {
  return `http://${config.amazonProxyOwnIp}:${config.amazonProxyPort}`;
}

function registrationData() {
  return remote?._options?.formerRegistrationData || null;
}

async function saveSession(data) {
  const formerRegistrationData = data?.formerRegistrationData || registrationData();
  if (!formerRegistrationData) throw new Error('Amazon authentication payload is missing formerRegistrationData.');
  await writeJson(config.amazonDataFile, {
    formerRegistrationData,
    savedAt: new Date().toISOString()
  });
  state.sessionSavedAt = new Date().toISOString();
}

function validateActiveSession() {
  if (!remote || validationInProgress) return;
  validationInProgress = true;
  transition(STATES.VALIDATING, 'checking Amazon session');
  remote.checkAuthentication((authenticated, error) => {
    validationInProgress = false;
    if (authenticated) {
      state.lastValidatedAt = new Date().toISOString();
      state.lastError = null;
      transition(STATES.AUTHENTICATED, 'Amazon session verified');
      startWatchdog();
      return;
    }
    const networkError = error && (
      ['ETIMEDOUT', 'EHOSTUNREACH', 'ENOTFOUND', 'EAI_AGAIN'].includes(error.code) ||
      /timeout|network|socket/i.test(error.message || '')
    );
    if (networkError) {
      state.lastError = String(error.message || error).slice(0, 400);
      transition(STATES.DEGRADED, 'session validation network error; saved session retained');
      return;
    }
    state.lastError = error ? String(error.message || error).slice(0, 400) : 'Amazon session expired or invalidated.';
    transition(STATES.AUTH_REQUIRED, 'Amazon session validation failed');
  });
}

function startWatchdog() {
  if (watchdog) clearInterval(watchdog);
  watchdog = setInterval(() => {
    if ([STATES.AUTHENTICATED, STATES.DEGRADED].includes(state.status)) {
      validateActiveSession();
    }
  }, 15 * 60 * 1000);
  watchdog.unref?.();
}

function getRemoteSession() {
  return { formerRegistrationData: registrationData() };
}

function handleInitCallback(error, result, mode) {
  if (error) {
    const message = String(error.message || error);
    const proxyReady = mode === 'login' &&
      (/please open|proxy listening|open this url/i.test(message) ||
       message.includes(String(config.amazonProxyPort)) ||
       message.includes('http://'));
    if (proxyReady) {
      state.proxyStartedAt = new Date().toISOString();
      state.lastError = null;
      transition(STATES.AUTHENTICATING, 'Amazon login proxy listening');
      log('info', 'Amazon login proxy is ready', { proxyUrl: proxyUrl() });
      return;
    }
    state.lastError = message.slice(0, 400);
    transition(STATES.ERROR, 'Amazon initialization failed');
    log('warn', 'Amazon authentication initialization failed', { message: state.lastError });
    return;
  }

  const sessionData = getRemoteSession();
  if (!sessionData.formerRegistrationData) {
    state.lastError = 'Amazon login completed but formerRegistrationData was not available.';
    transition(STATES.AUTH_REQUIRED, 'session data unavailable');
    try { remote?.stopProxy?.(); } catch {}
    return;
  }

  saveSession(sessionData).then(() => {
    log('info', 'Amazon authentication payload saved');
    validateActiveSession();
  }).catch(saveError => {
    state.lastError = String(saveError.message || saveError).slice(0, 400);
    transition(STATES.AUTH_REQUIRED, 'session persistence failed');
    log('error', 'Could not persist Amazon session', { message: state.lastError });
  });
}

function initializeRemote({ savedRegistrationData = null, mode = 'login' } = {}) {
  if (remote) return;
  remote = new AlexaRemote();
  // alexa-remote2 emits this after initial authentication and token refresh.
  // Persist the complete formerRegistrationData object, not only cookieData.
  remote.on('cookie', () => {
    saveSession(getRemoteSession()).catch(error => {
      state.lastError = String(error?.message || error).slice(0, 400);
      log('error', 'Could not persist refreshed Amazon session', { message: state.lastError });
    });
  });

  const options = {
    amazonPage: 'amazon.com',
    baseAmazonPage: 'amazon.com',
    amazonPageProxyLanguage: 'en_US',
    acceptLanguage: 'en-US',
    userLanguage: 'en-US',
    alexaServiceHost: 'alexa.amazon.com',
    proxyOnly: mode === 'login',
    proxyOwnIp: config.amazonProxyOwnIp,
    proxyPort: config.amazonProxyPort,
    proxyListenBind: '0.0.0.0',
    proxyLogLevel: 'info',
    usePushConnection: false,
    cookieRefreshInterval: 7 * 24 * 60 * 60 * 1000,
    ...(savedRegistrationData ? {
      formerRegistrationData: savedRegistrationData,
      cookie: savedRegistrationData.localCookie,
      useLocalCookie: true
    } : {})
  };

  log('info', 'Initializing Amazon client', {
    mode,
    amazonPage: options.amazonPage,
    amazonPageProxyLanguage: options.amazonPageProxyLanguage,
    acceptLanguage: options.acceptLanguage,
    userLanguage: options.userLanguage,
    alexaServiceHost: options.alexaServiceHost,
    proxyOwnIp: options.proxyOwnIp,
    proxyPort: options.proxyPort,
    restoringSession: Boolean(savedRegistrationData)
  });

  remote.init(options, (error, result) => handleInitCallback(error, result, mode));
}

export function amazonStatus() {
  return {
    ...state,
    proxyPort: config.amazonProxyPort,
    proxyOwnIp: config.amazonProxyOwnIp,
    proxyUrl: proxyUrl()
  };
}

export async function loadAmazonState() {
  const savedInventory = await readJson(config.amazonInventoryFile, { devices: [], retrievedAt: null });
  inventory = Array.isArray(savedInventory.devices) ? savedInventory.devices : [];
  state.inventoryCount = inventory.length;
  state.lastInventoryAt = savedInventory.retrievedAt || null;

  const savedSession = await readJson(config.amazonDataFile, null);
  if (savedSession?.formerRegistrationData) {
    state.sessionSavedAt = savedSession.savedAt || null;
    transition(STATES.VALIDATING, 'restoring saved Amazon session');
    initializeRemote({ savedRegistrationData: savedSession.formerRegistrationData, mode: 'restore' });
  } else {
    transition(STATES.AUTH_REQUIRED, 'no saved Amazon session');
  }
}

export function startAmazonLogin() {
  const task = operation.then(async () => {
    if (remote && [STATES.AUTHENTICATING, STATES.AUTHENTICATED, STATES.DEGRADED].includes(state.status)) {
      return { started: true, status: state.status, proxyUrl: proxyUrl() };
    }
    if (remote) {
      try { remote.stop?.(); } catch {}
      remote = null;
    }
    state.lastError = null;
    state.proxyStartedAt = new Date().toISOString();
    transition(STATES.AUTHENTICATING, 'starting Amazon proxy login');
    initializeRemote({ mode: 'login' });
    return { started: true, status: STATES.AUTHENTICATING, proxyUrl: proxyUrl() };
  });
  operation = task.catch(() => {});
  return task;
}

export async function refreshAmazonInventory() {
  if (!remote || !state.authenticated) {
    throw new Error('Amazon account is not authenticated. Complete Amazon login first.');
  }
  const result = await new Promise((resolve, reject) => {
    if (typeof remote.getSmarthomeDevicesV2 !== 'function') {
      reject(new Error('Installed alexa-remote2 does not provide getSmarthomeDevicesV2().'));
      return;
    }
    remote.getSmarthomeDevicesV2((error, devices) => error ? reject(error) : resolve(devices));
  });

  const rows = Array.isArray(result) ? result
    : Array.isArray(result?.devices) ? result.devices
    : Array.isArray(result?.appliances) ? result.appliances
    : Array.isArray(result?.entities) ? result.entities
    : Array.isArray(result?.smarthomeDevices) ? result.smarthomeDevices
    : null;
  if (!rows) throw new Error('Amazon returned an unrecognized Smart Home inventory response; cached inventory was preserved.');

  const next = rows.map((item, index) => {
    const source = item && typeof item === 'object' ? item : { value: item };
    return {
      index,
      entityId: source.entityId ?? source.id ?? source.applianceId ?? null,
      entityType: source.entityType ?? source.type ?? null,
      name: source.name ?? source.friendlyName ?? source.displayName ?? null,
      manufacturer: source.manufacturer ?? null,
      model: source.model ?? null,
      capabilities: Array.isArray(source.capabilities) ? source.capabilities : [],
      properties: Array.isArray(source.properties) ? source.properties : [],
      raw: source
    };
  });

  const retrievedAt = new Date().toISOString();
  await writeJson(config.amazonInventoryFile, { retrievedAt, devices: next });
  inventory = next;
  state.lastInventoryAt = retrievedAt;
  state.inventoryCount = next.length;
  state.lastError = null;
  return { retrievedAt, count: next.length, devices: next };
}

export function getAmazonInventory() {
  return { retrievedAt: state.lastInventoryAt, count: inventory.length, devices: inventory };
}
