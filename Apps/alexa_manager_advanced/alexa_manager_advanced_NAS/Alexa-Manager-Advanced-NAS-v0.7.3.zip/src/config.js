import { resolve } from 'node:path';

const amazonProxyPort = Number.parseInt(process.env.AMAZON_PROXY_PORT || '3456', 10);
if (!Number.isInteger(amazonProxyPort) || amazonProxyPort < 1 || amazonProxyPort > 65535) throw new Error('Invalid AMAZON_PROXY_PORT');

const port = Number.parseInt(process.env.PORT || '4100', 10);
if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error('Invalid PORT');

export const config = Object.freeze({
  appVersion: '0.7.3',
  nodeEnv: process.env.NODE_ENV || 'production',
  influxEnabled: /^(1|true|yes|on)$/i.test(process.env.INFLUX_ENABLED || 'false'),
  influxUrl: (process.env.INFLUX_URL || '').replace(/\/$/, ''),
  influxOrg: process.env.INFLUX_ORG || '',
  influxBucket: process.env.INFLUX_BUCKET || '',
  influxToken: process.env.INFLUX_TOKEN || '',
  port,
  amazonProxyPort,
  amazonProxyOwnIp: process.env.AMAZON_PROXY_OWN_IP || '192.168.1.23',
  amazonServiceHost: process.env.AMAZON_SERVICE_HOST || 'layla.amazon.com',
  amazonDataFile: resolve(process.env.DATA_DIR || '/app/data', 'amazon-session.json'),
  amazonInventoryFile: resolve(process.env.DATA_DIR || '/app/data', 'amazon-inventory.json'),
  apiKey: process.env.AMA_API_KEY || '',
  publicBaseUrl: (process.env.PUBLIC_BASE_URL || 'https://alexa.e-wiz.com').replace(/\/$/, ''),
  oauthUsername: process.env.OAUTH_USERNAME || '',
  oauthPassword: process.env.OAUTH_PASSWORD || '',
  oauthClientId: process.env.OAUTH_CLIENT_ID || '',
  oauthClientSecret: process.env.OAUTH_CLIENT_SECRET || '',
  oauthAllowedRedirectHosts: (process.env.OAUTH_ALLOWED_REDIRECT_HOSTS || '').split(',').map(x => x.trim().toLowerCase()).filter(Boolean),
  dataFile: resolve(process.env.DATA_DIR || '/app/data', 'oauth-store.json'),
  deviceFile: resolve(process.env.DATA_DIR || '/app/data', 'devices.json')
});
