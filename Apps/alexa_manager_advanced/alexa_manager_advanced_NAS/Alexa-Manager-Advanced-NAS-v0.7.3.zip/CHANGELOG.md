# Alexa Manager Advanced NAS Changelog

## v0.7.3 - 2026-11-12
- Synchronizes the runtime-reported service version with the package version (`0.7.3`), so health, status, monitoring, startup logs, and Influx telemetry report the same release.
- Replaces the stale 0.7.0 README with documentation for the current 0.7.3 NAS service, current APIs, current Amazon inventory integration, monitoring behavior, and deployment workflow.
- Updates deployment instructions to describe the complete backup/archive model used for this installation, including `.env` and the `data/` snapshot, while clearly distinguishing a source overlay from restoring runtime data.
- Documents the current InfluxDB configuration as `DundeeHome / HubAlexa` and clarifies that the test-write endpoint is an explicit diagnostic operation independent of continuous telemetry enablement.
- Corrects version references and removes obsolete companion-app release references from the NAS documentation.
- No changes to Amazon authentication/session behavior, OAuth behavior, API-key handling, InfluxDB write behavior, device exposure, or the running data format.

## v0.7.2 - 2026-11-11
- Adds an install-time, AMA-local compatibility patch to the installed `alexa-cookie2` proxy.
- Removes only Amazon's `upgrade-insecure-requests` directive from proxied Content-Security-Policy headers, preventing browser HTTPS upgrades of the local HTTP-only login proxy.
- Preserves other CSP directives, Amazon redirects, cookie handling, proxy listener behavior, and the Echos Speak authentication/session lifecycle model.
- Patch is reapplied automatically during `npm install` / Docker image builds and is idempotent.
- Does not modify Echos Speak, persistent Amazon session data, inventory data, Hubitat APIs, or Docker Compose configuration.

## v0.7.1 - 2026-11-11
- Reworks Amazon authentication to follow the proven Echos Speak `alexa-remote2` session lifecycle.
- Uses US Amazon region and English login settings (`amazon.com`, `en_US`, `en-US`, `alexa.amazon.com`).
- Uses the complete `formerRegistrationData` payload for persistent session storage and restoration, including the local cookie expected by `alexa-remote2`.
- Adds explicit Amazon session validation and a 15-minute validation watchdog.
- Separates `AUTHENTICATING`, `AUTHENTICATED`, `AUTH_REQUIRED`, `DEGRADED`, and `ERROR` states.
- Keeps Amazon session and household inventory files separate from Hubitat device registry and OAuth storage.
- Retains read-only household inventory retrieval through `getSmarthomeDevicesV2()`.
- Preserves existing Hubitat, OAuth, monitoring, and InfluxDB APIs.

## v0.7.0 - 2026-11-11
- Initial Amazon household inventory integration and login proxy.
