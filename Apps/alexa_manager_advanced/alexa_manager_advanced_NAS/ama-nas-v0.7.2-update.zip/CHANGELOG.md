# Alexa Manager Advanced NAS Changelog

## v0.7.2 - 2026-11-11
- Adds an install-time, AMA-local compatibility patch to the installed `alexa-cookie2` proxy.
- Removes only Amazon's `upgrade-insecure-requests` directive from proxied Content-Security-Policy headers, preventing browser HTTPS upgrades of the local HTTP-only login proxy.
- Preserves other CSP directives, Amazon redirects, cookie handling, proxy listener behavior, and the Echos Speak authentication/session lifecycle model.
- Patch is reapplied automatically during `npm install` / Docker image builds and is idempotent.
- Does not modify Echos Speak, persistent Amazon session data, inventory data, Hubitat APIs, or Docker Compose configuration.

## v0.7.1 - 2026-11-11
- Reworks Amazon authentication to follow the proven Echos Speak `alexa-remote2` session lifecycle.
- Uses US Amazon region and English login settings (`amazon.com`, `en_US`, `en-US`, `alexa.amazon.com`).
- Uses the complete `formerRegistrationData` payload for persistent session storage and restoration, including the local cookie expected by `alexa-remote2`.
- Adds explicit Amazon session validation and a 15-minute validation watchdog.
- Separates `AUTHENTICATING`, `AUTHENTICATED`, `AUTH_REQUIRED`, `DEGRADED`, and `ERROR` states.
- Keeps Amazon session and household inventory files separate from Hubitat device registry and OAuth storage.
- Retains read-only household inventory retrieval through `getSmarthomeDevicesV2()`.
- Preserves existing Hubitat, OAuth, monitoring, and InfluxDB APIs.

## v0.7.0 - 2026-11-11
- Initial Amazon household inventory integration and login proxy.
