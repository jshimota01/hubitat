/**
 * AMA NAS v0.7.2
 * Applies a narrowly scoped compatibility patch to alexa-cookie2's Amazon
 * response proxy. Amazon currently sends a CSP upgrade-insecure-requests
 * directive on proxied pages. That directive upgrades the proxy's local
 * HTTP navigation to HTTPS, but the local cookie proxy is intentionally
 * HTTP-only (same design used by Echos Speak).
 *
 * Only that CSP directive is removed. Other CSP directives, response
 * headers, redirects, cookies, and the dependency's proxy logic are kept.
 */
import { readFile, writeFile } from 'node:fs/promises';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const alexaCookieEntry = require.resolve('alexa-cookie2');
const path = await import('node:path');
const proxyPath = path.join(path.dirname(alexaCookieEntry), 'lib', 'proxy.js');

let source = await readFile(proxyPath, 'utf8');
const marker = "        if (proxyRes && proxyRes.headers && proxyRes.headers['set-cookie']) {";
if (source.includes('AMA: remove Amazon CSP upgrade-insecure-requests')) {
  console.log('AMA proxy compatibility patch already present.');
} else {
  if (!source.includes(marker)) {
    throw new Error(`Expected alexa-cookie2 proxy response hook not found in ${proxyPath}; refusing to patch an unknown version.`);
  }
  const insertion = `        // AMA: remove Amazon CSP upgrade-insecure-requests so the HTTP-only
        // local authentication proxy is not upgraded to HTTPS by the browser.
        if (proxyRes && proxyRes.headers) {
            for (const headerName of ['content-security-policy', 'content-security-policy-report-only']) {
                const policy = proxyRes.headers[headerName];
                if (typeof policy === 'string') {
                    const filtered = policy
                        .split(';')
                        .map(part => part.trim())
                        .filter(part => part && !/^upgrade-insecure-requests$/i.test(part));
                    if (filtered.length) proxyRes.headers[headerName] = filtered.join('; ');
                    else delete proxyRes.headers[headerName];
                }
            }
        }

`;
  source = source.replace(marker, insertion + marker);
  await writeFile(proxyPath, source, 'utf8');
  console.log('Applied AMA proxy compatibility patch to alexa-cookie2.');
}
