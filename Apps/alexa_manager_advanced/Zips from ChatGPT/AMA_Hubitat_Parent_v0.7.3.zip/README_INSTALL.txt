AMA Hubitat Parent v0.7.3
==========================

Purpose
-------
Adds Hubitat-originated switch event telemetry to the existing Parent -> Monitoring & Analytics path.

What changed
------------
- The Parent's existing `switchDevices` subscriptions now forward each switch event to
  `AMA Monitoring & Analytics` as `device.state.updated`.
- The payload includes Hubitat device ID, AMA endpoint ID, device name, attribute,
  value, power state, unit, description, and event source.
- Telemetry forwarding is independent of NAS API configuration.
- Existing NAS state synchronization remains in place and runs after telemetry forwarding.
- No child-to-child communication was added.
- No candidate discovery, approval, exposure, Alexa directive, or NAS service behavior changed.

Important scope
---------------
This uses the Parent's existing hidden `switchDevices` selection. It does not automatically
subscribe every inventory candidate. Candidate selection/preparation is not the same as
Alexa exposure, and the current Exposure Management branch does not yet implement an
authoritative exposed-device list.

Install
-------
In Hubitat, replace the existing Alexa Manager Advanced parent app code with the contents
of `alexa_manager_advanced_parent_v0.7.3.groovy`, then Save. Open the parent app and
Done/Update if prompted so `updated()` and `initialize()` run.

The Monitoring & Analytics child does not need a code update. Its InfluxDB measurement
is `ama_hubitat`, not `ama_nas`.

Verification
------------
1. Confirm Bathroom Fan is still selected under the Parent's hidden legacy switch endpoint
   selection (`switchDevices`). Do not alter it if it is already selected.
2. Confirm Hubitat telemetry is enabled in Monitoring & Analytics.
3. Toggle Bathroom Fan from the Hubitat GUI.
4. Query InfluxDB measurement `ama_hubitat` for event `device.state.updated`.
5. The event payload should include `hubitatDeviceId` and `endpointId` (`hubitat-558`).

Version history
---------------
v0.7.3 - Adds Parent-mediated switch state event telemetry.
v0.7.2 - Aligns parent and Monitoring & Analytics module names.
