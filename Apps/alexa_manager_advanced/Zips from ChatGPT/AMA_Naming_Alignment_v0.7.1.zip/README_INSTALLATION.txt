Alexa Manager Advanced — Naming Alignment Update
Date: 2026-11-10

FILES
- alexa_manager_advanced_parent_v0.7.1.groovy
- ama_candidate_selection_child_v0.3.1.groovy
- ama_candidate_preparation_child_v0.3.1.groovy
- ama_exposure_management_child_v0.1.1.groovy
- ama_monitoring_analytics_child_v0.1.6.groovy

CANONICAL CHILD APP TYPE NAMES
1. AMA Candidate Selection
2. AMA Candidate Preparation
3. AMA Exposure Management
4. AMA Monitoring & Analytics

WHAT CHANGED
- The Hubitat app definition names now match the branch names.
- The parent app() declarations use those exact names.
- All parent child lookups and module-status references use the canonical names.
- Child parent declarations still point to jshimota:Alexa Manager Advanced.
- Installed display labels remain versioned and use the canonical branch names.
- Parent child lookup retains a legacy-name fallback to help find already-installed children during transition.
- No child-to-child communication was added; the parent remains the only coordinator.

VERSION CHANGES
- Parent 0.7.0 -> 0.7.1
- Candidate Selection 0.3.0 -> 0.3.1
- Candidate Preparation 0.3.0 -> 0.3.1
- Exposure Management 0.1.0 -> 0.1.1
- Monitoring & Analytics 0.1.5 -> 0.1.6

INSTALLATION CAUTION
Because the Hubitat child app definition names are changing, back up the five current source files first.
Update the four child app code definitions, then update the parent app code. Do not uninstall the parent or children.
After saving each child source, confirm its installed instance remains present and its existing state is retained.
If Hubitat treats a renamed definition as a new child app type rather than updating the installed type, stop before deleting or reinstalling anything and report what the Apps Code / installed-app screens show. The parent includes legacy lookup fallback, but Hubitat's app-type migration behavior must be verified on the hub.

These sources have not been compiled or executed on the user's Hubitat hub in this session.
