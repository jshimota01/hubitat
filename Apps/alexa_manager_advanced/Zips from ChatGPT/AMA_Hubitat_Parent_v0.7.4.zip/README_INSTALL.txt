AMA Hubitat Parent v0.7.4
==========================

Fixes the stale Hubitat switch callback reported after installing v0.7.3.

Changes:
- Calls `unsubscribe()` during parent initialization to clear subscriptions retained
  from older app versions.
- Registers the current `legacySwitchEventHandler` callback after clearing old
  subscriptions.
- Retains `switchEventHandler(evt)` as a compatibility wrapper in case Hubitat invokes
  an already-queued callback during the update.
- Keeps v0.7.3 Parent-to-Monitoring & Analytics event forwarding and NAS state sync.

Install:
1. Replace the parent app code with `alexa_manager_advanced_parent_v0.7.4.groovy`.
2. Save the code.
3. Open the installed Alexa Manager Advanced parent app and press Done/Update if prompted.
4. Check Logs for `Parent initialized` and confirm no MissingMethodException appears.
5. Toggle Bathroom Fan once from Hubitat and then query `ama_hubitat`.

No NAS container rebuild or child-app code change is required.
