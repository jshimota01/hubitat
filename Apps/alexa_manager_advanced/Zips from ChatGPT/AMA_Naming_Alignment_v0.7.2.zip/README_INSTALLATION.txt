Alexa Manager Advanced — Newest-Code Naming Alignment
Date: 2026-11-10

BASELINE
- Parent v0.7.1
- Candidate Selection v0.3.1
- Candidate Preparation v0.3.1
- Exposure Management v0.1.1
- Monitoring & Analytics v0.2.0 (direct InfluxDB 2.x writer)

OUTPUT
- Parent v0.7.2
- Candidate Selection v0.3.2
- Candidate Preparation v0.3.2
- Exposure Management v0.1.2
- Monitoring & Analytics v0.2.1

CANONICAL CHILD APP TYPE NAMES
1. AMA Candidate Selection
2. AMA Candidate Preparation
3. AMA Exposure Management
4. AMA Monitoring & Analytics

CHANGES
- All four child definition(name:) values match the canonical names.
- Parent app() declarations and child lookup call sites use those names.
- Parent child lookup retains explicit fallback matches for the prior internal names:
  AMA Device Handling Child, AMA Device Management Child,
  AMA Exposure Management Child, AMA Monitoring & Analytics Child.
- All children remain parented to jshimota:Alexa Manager Advanced.
- Monitoring & Analytics is based on v0.2.0 and retains its InfluxDB configuration,
  test write, asynchronous reporting, status and failure handling.
- No child-to-child communication was added.

INSTALLATION
1. Back up the five currently installed source files.
2. Update the four child code entries with their matching files.
3. Update the parent code entry last.
4. Do not uninstall or recreate any parent or child app instance.
5. Save each existing child instance and confirm it remains present.
6. Confirm the Monitoring & Analytics InfluxDB settings are still present.
   Telemetry remains disabled until explicitly enabled.

STOP CONDITION
Hubitat's behavior when a child app definition name changes must be confirmed live.
If an existing child disappears, becomes orphaned, or Hubitat offers a new install
instead of updating the existing instance, stop and do not uninstall anything.

Static checks performed for app definition names, parent declarations, parent child
references, legacy lookup fallback, and presence of InfluxDB writer implementation.
Not compiled or executed on the Hubitat hub in this session.
