Alexa Manager Advanced update - 2026-11-10

Included source updates:
- Alexa Manager Advanced Parent v0.5.4
- AMA Device Handling Child v0.1.4
- AMA Device Management Child v0.1.3
- AMA Monitoring & Analytics Child v0.1.3

Installation:
1. Back up the four currently installed Groovy source files.
2. Replace the source in each existing Hubitat app code entry with its matching file.
3. Save the code and open the existing app instance, then press Done/Save as appropriate.
4. Do not uninstall or recreate the parent or child app instances. Existing app identities and state are intended to be preserved.
5. Open Device Handling, run a scan, then use Review Collected Data to inspect records.
6. Open Device Management, choose Review Devices & Manage Approval, select a verified device, and explicitly approve or revoke it.

Behavior and safety:
- Device Handling review is read-only.
- Approval is stored as management metadata only.
- Approval does NOT register or expose an endpoint to Amazon.
- Revocation does NOT issue an Amazon deregistration request.
- A device must be verified present in the latest scan before it can be newly approved.
- Existing approval can still be revoked if a device is no longer verified.
- Inventory records are retained; unselected/failed/filtered records are marked unverified rather than deleted.
- No Echos Speak files, services, credentials, containers, or databases are changed.

Validation note:
These files received static source checks (balanced braces/parentheses and targeted code-path review).
They have not yet been installed or executed on the Hubitat hub. Perform the live scan and UI verification before treating runtime behavior as confirmed.
