AMA Hubitat Parent v0.7.5

Adds a parent-owned `forwardTelemetryEvent(eventName, payload)` service method.
The Parent sends the complete event envelope to the NAS endpoint
`/api/v1/telemetry/hubitat-event` using the Parent's existing AMA URL and API key.
Child-to-child communication is not introduced.

This version also includes the v0.7.4 stale-subscription cleanup and callback
compatibility wrapper. The internal version() string is 0.7.5.

Install after deploying NAS v0.5.2:
1. Replace the Parent app code with the included Groovy file.
2. Save and update the installed Parent app.
3. Monitoring & Analytics v0.2.4 should then call the Parent's
   `forwardTelemetryEvent()` method when it receives a parent event.
