const express = require('express');
const authManager = require('./authManager');
const logger = require('./logger');

const app = express();
const PORT = process.env.PORT || 4000;
const PROXY_PORT = process.env.PROXY_PORT || 4001;
const PROXY_HOST = process.env.PROXY_PUBLIC_HOST || '192.168.1.12';

app.use(express.json());

app.use((req, res, next) => {
  res.removeHeader('Access-Control-Allow-Origin');
  next();
});

// GET /auth/status
app.get('/auth/status', (req, res) => {
  const status = authManager.getStatus();
  logger.info(`[Server] GET /auth/status requested from ${req.ip} -> State: ${status.state}`);
  res.json(status);
});

// POST /auth/login
app.post('/auth/login', (req, res) => {
  logger.info(`[Server] POST /auth/login received from ${req.ip}`);
  const currentStatus = authManager.getStatus();

  if (currentStatus.state === 'AUTHENTICATING') {
    logger.info('[Server] Proxy login already in progress. Returning existing proxy URL...');
    return res.json({
      message: 'Proxy login already in progress.',
      proxyUrl: `http://${PROXY_HOST}:${PROXY_PORT}`,
      status: currentStatus,
    });
  }

  logger.info('[Server] Triggering authManager.startProxyAuth()...');
  authManager.startProxyAuth();

  res.json({
    message: 'Proxy authentication initialized.',
    proxyUrl: `http://${PROXY_HOST}:${PROXY_PORT}`,
    instructions: `Open http://${PROXY_HOST}:${PROXY_PORT} in a browser and complete Amazon login.`,
  });
});

app.listen(PORT, () => {
  logger.info(`==================================================`);
  logger.info(`Echos Speak Server running on port ${PORT}`);
  logger.info(`Configured Proxy Public Host: http://${PROXY_HOST}:${PROXY_PORT}`);
  logger.info(`==================================================`);
  authManager.boot();
});