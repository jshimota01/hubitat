/**
 * Command Dispatcher for Echos Speak Bridge
 * Handles routing incoming API actions to alexa-remote2 method calls.
 **/

function handleCommand(req, res, alexa) {
    const body = (req && req.body) ? req.body : {};
    const { serialNumber, command, payload = {} } = body;

    if (!command) {
        return res.status(400).json({ success: false, error: 'Command parameter is required.' });
    }

    // Global Announce All handling
    if (command === 'announceAll') {
        const textToAnnounce = payload.text || payload.rawPayload || '';
        if (!textToAnnounce) {
            return res.status(400).json({ success: false, error: 'Text payload required for announceAll' });
        }
        return alexa.sendSequenceCommand(null, 'announcement', textToAnnounce, (err, result) => {
            if (err) {
                console.error('[Bridge Error] announceAll failed:', err);
                return res.status(500).json({ success: false, error: err.message });
            }
            return res.json({ success: true, command: 'announceAll', result });
        });
    }

    // Resolve target device
    if (!serialNumber) {
        return res.status(400).json({ success: false, error: 'serialNumber parameter is required for this command.' });
    }

    const devices = alexa.serialNumbers || {};
    const targetDevice = devices[serialNumber];

    if (!targetDevice) {
        console.error(`[Bridge Error] Device serial number ${serialNumber} not found in active session map.`);
        return res.status(404).json({ success: false, error: `Device ${serialNumber} not found.` });
    }

    switch (command) {
        case 'speak': {
            const textToSpeak = payload.text || payload.rawPayload || '';
            if (!textToSpeak) {
                return res.status(400).json({ success: false, error: 'Text payload required for speak' });
            }
            alexa.sendSequenceCommand(targetDevice, 'speak', textToSpeak, (err, result) => {
                if (err) {
                    console.error(`[Bridge Error] speak failed for ${serialNumber}:`, err);
                    return res.status(500).json({ success: false, error: err.message });
                }
                return res.json({ success: true, serialNumber, command: 'speak', result });
            });
            break;
        }

        case 'announce': {
            const textToAnnounce = payload.text || payload.rawPayload || '';
            if (!textToAnnounce) {
                return res.status(400).json({ success: false, error: 'Text payload required for announce' });
            }
            alexa.sendSequenceCommand(targetDevice, 'announcement', textToAnnounce, (err, result) => {
                if (err) {
                    console.error(`[Bridge Error] announce failed for ${serialNumber}:`, err);
                    return res.status(500).json({ success: false, error: err.message });
                }
                return res.json({ success: true, serialNumber, command: 'announce', result });
            });
            break;
        }

        case 'voiceCmdAsText':
        case 'textCommand': {
            const textToRun = payload.text || payload.rawPayload || '';
            if (!textToRun) {
                return res.status(400).json({ success: false, error: 'Text payload is required for voiceCmdAsText' });
            }
            alexa.sendSequenceCommand(targetDevice, 'textCommand', textToRun, (err, result) => {
                if (err) {
                    console.error(`[Bridge Error] voiceCmdAsText failed for ${serialNumber}:`, err);
                    return res.status(500).json({ success: false, error: err.message });
                }
                return res.json({ success: true, serialNumber, command: 'voiceCmdAsText', result });
            });
            break;
        }

        case 'volume': {
            const level = payload.level !== undefined ? parseInt(payload.level, 10) : 50;
            alexa.sendSequenceCommand(targetDevice, 'volume', level, (err, result) => {
                if (err) {
                    console.error(`[Bridge Error] volume failed for ${serialNumber}:`, err);
                    return res.status(500).json({ success: false, error: err.message });
                }
                return res.json({ success: true, serialNumber, command: 'volume', level, result });
            });
            break;
        }

        case 'volumeUp': {
            const currentVol = targetDevice.currentVolume !== null && targetDevice.currentVolume !== undefined 
                ? parseInt(targetDevice.currentVolume, 10) 
                : 50;
            const targetVol = Math.min(100, currentVol + 5);
            alexa.sendSequenceCommand(targetDevice, 'volume', targetVol, (err, result) => {
                if (err) {
                    console.error(`[Bridge Error] volumeUp failed for ${serialNumber}:`, err);
                    return res.status(500).json({ success: false, error: err.message });
                }
                return res.json({ success: true, serialNumber, command: 'volumeUp', level: targetVol, result });
            });
            break;
        }

        case 'volumeDown': {
            const currentVol = targetDevice.currentVolume !== null && targetDevice.currentVolume !== undefined 
                ? parseInt(targetDevice.currentVolume, 10) 
                : 50;
            const targetVol = Math.max(0, currentVol - 5);
            alexa.sendSequenceCommand(targetDevice, 'volume', targetVol, (err, result) => {
                if (err) {
                    console.error(`[Bridge Error] volumeDown failed for ${serialNumber}:`, err);
                    return res.status(500).json({ success: false, error: err.message });
                }
                return res.json({ success: true, serialNumber, command: 'volumeDown', level: targetVol, result });
            });
            break;
        }

        case 'mute': {
            alexa.sendSequenceCommand(targetDevice, 'volume', 0, (err, result) => {
                if (err) {
                    console.error(`[Bridge Error] mute failed for ${serialNumber}:`, err);
                    return res.status(500).json({ success: false, error: err.message });
                }
                return res.json({ success: true, serialNumber, command: 'mute', result });
            });
            break;
        }

        case 'unmute': {
            const restoreLevel = payload.level !== undefined ? parseInt(payload.level, 10) : 50;
            alexa.sendSequenceCommand(targetDevice, 'volume', restoreLevel, (err, result) => {
                if (err) {
                    console.error(`[Bridge Error] unmute failed for ${serialNumber}:`, err);
                    return res.status(500).json({ success: false, error: err.message });
                }
                return res.json({ success: true, serialNumber, command: 'unmute', level: restoreLevel, result });
            });
            break;
        }

        case 'dnd': {
            const dndState = payload.state !== undefined ? Boolean(payload.state) : true;
            alexa.sendSequenceCommand(targetDevice, 'deviceDoNotDisturb', dndState, (err, result) => {
                if (err) {
                    console.error(`[Bridge Error] dnd failed for ${serialNumber}:`, err);
                    return res.status(500).json({ success: false, error: err.message });
                }
                return res.json({ success: true, serialNumber, command: 'dnd', state: dndState, result });
            });
            break;
        }

        case 'play':
            alexa.sendCommand(targetDevice, 'play', (err, result) => res.json({ success: !err, result }));
            break;
        case 'pause':
            alexa.sendCommand(targetDevice, 'pause', (err, result) => res.json({ success: !err, result }));
            break;
        case 'stop':
            alexa.sendCommand(targetDevice, 'stop', (err, result) => res.json({ success: !err, result }));
            break;
        case 'nextTrack':
            alexa.sendCommand(targetDevice, 'next', (err, result) => res.json({ success: !err, result }));
            break;
        case 'previousTrack':
            alexa.sendCommand(targetDevice, 'previous', (err, result) => res.json({ success: !err, result }));
            break;

        default:
            return res.status(400).json({ success: false, error: `Unsupported command: ${command}` });
    }
}

module.exports = {
    handleCommand,
    dispatch: handleCommand
};