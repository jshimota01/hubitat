WeatherIcons

Icons provided by:

VClouds Weather Icons by VClouds VClouds Weather Icons© Created and copyrighted© by VClouds - http://vclouds.deviantart.com/

The icons are free to use for Non-Commercial use, but If you use want to use it with your art please credit me and put a link leading back to the icons DA page - http://vclouds.deviantart.com/gallery/#/d2ynulp

*** Not to be used for commercial use without permission! if you want to buy the icons for commercial use please send me a note - http://vclouds.deviantart.com/ ***
