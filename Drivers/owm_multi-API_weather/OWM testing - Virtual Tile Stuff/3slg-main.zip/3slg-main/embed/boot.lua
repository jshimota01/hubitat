--[[
###############################################################################

                                特別授業SLG
                                  基本定義

                             ***** 注意 *****
               許可なく本ファイルの内容を変更しないで下さい。
         許可なく変更した結果については全て自己責任でお願いします。

###############################################################################
]]

math.randomseed( os.time() );

KEY_A	= 0x41;
KEY_B	= 0x42;
KEY_WU	= 0x3c;
KEY_WD	= 0x3e;

-------------------------------------------------------------------------------

local translation_map = {};

for _, entry in ipairs(OpenCSVDB( "translation" )) do
	local original_name = entry["Original"];
	local translated_name = entry["Translated"];
	if original_name and translated_name and original_name ~= "" and translated_name ~= "" then
		translation_map[original_name] = translated_name;
	end
end


function translate( text )
	return translation_map[text] or text
end

-------------------------------------------------------------------------------

function split( s, delim )
	delim	= delim or ",";

	if string.find( s, delim ) == nil then
		return { s };
	end

	local	result	= {};
	local	pattern	= "(.-)" .. delim .. "()";
	local	last;
	for token, pos in string.gmatch( s, pattern ) do
		result[#result + 1]	= token;
		last	= pos;
	end
	result[#result + 1]	= string.sub( s, last );
	return result;
end

-------------------------------------------------------------------------------

LoadExScript( "ScrollBar" );
LoadExScript( "CHInfoWindow" );
LoadExScript( "territory" );
LoadExScript( "training" );
LoadExScript( "day_result" );
LoadExScript( "check_achievement" );

--保存対象のデータテーブル
CommonData	= CommonData or {};
PrivateData	= PrivateData or {};

function StoreCommonData( _out )
	OutputData( _out, CommonData );
end

function RestoreCommonData( _in )
	InputData( _in, CommonData );
end

function StorePrivateData( _out )
	OutputData( _out, PrivateData );
end

function RestorePrivateData( _in )
	InputData( _in, PrivateData );
end