--[[
###############################################################################

                                特別授業SLG
                               実績解除確認

                             ***** 注意 *****
               許可なく本ファイルの内容を変更しないで下さい。
         許可なく変更した結果については全て自己責任でお願いします。

###############################################################################
]]

function CheckAndUnlockAchievement( ... )
	for i = 1,select("#",...) do
		CheckAndUnlockAchievementOne( select(i,...) )
	end
end

function CheckAndUnlockAchievementOne( id )
	if CheckAchievement( id ) then
		return;
	end

	local	func	= AchievementChecker[id];
	
	if not func then
		print( "CheckAndUnlockAchievement IDが見つかりません。: " .. id );
		return;
	end

	if not func() then
		return;
	end

	UnlockAchievement( id );
end

-------------------------------------------------------------------------------

AchievementChecker	= AchievementChecker or {};

-------------------------------------------------------------------------------

function AchievementChecker:ID50()
	local	i, obj0, obj1, obj2;

	--調教マスター：すべての調教を、一回以上行いました。
	for i = 0,48 do
		if i ~= 37 and i ~= 38 then
			obj0	= GetDB( "#ID_TC", 0, i );
			obj1	= GetDB( "#ID_TC", 1, i );
			obj2	= GetDB( "#ID_TC", 2, i );

			--一人も実行したことがない調教があったらout
			if not obj0 or ( obj0 <= 0 and obj1 <= 0 and obj2 <= 0 ) then
				return false;
			end
		end
	end

	--固定調教
	obj0	= GetScenarioValue( "#saki_ev3" );
	obj1	= GetScenarioValue( "#arisa_ev3" );
	obj2	= GetScenarioValue( "#mikako_ev3" );
	for i = 0,6 do
		if not bit32.btest( obj0, bit32.lshift( 0x1, i ) ) and not bit32.btest( obj1, bit32.lshift( 0x1, i ) ) and not bit32.btest( obj2, bit32.lshift( 0x1, i ) ) then
			return false;
		end
	end
	
	if GetScenarioValue( "#combiH" ) ~= 3 then
		return false;
	end
	
	for i = 0,4 do
		obj0	= GetDB( "#ID_STC", 0, i );
		obj1	= GetDB( "#ID_STC", 1, i );
		obj2	= GetDB( "#ID_STC", 2, i );

		--一人も実行したことがない調教があったらout
		if not obj0 or ( obj0 <= 0 and obj1 <= 0 and obj2 <= 0 ) then
			return false;
		end
	end

	return true;
end

-------------------------------------------------------------------------------

function AchievementChecker:ID51()
	local	i, c, ch, obj;

	--万能奴隷：いずれかのヒロインに、すべての調教を１回以上施しました。
	for ch = 0,2 do
		c	= 0;
		for i = 0,48 do
			if i ~= 37 and i ~= 38 then
				obj		= GetDB( "#ID_TC", ch, i );
				if not obj or obj <= 0 then
					break;
				end
				c	= c + 1;
			end
		end
		if c == 47 then
			if ch ~= 0 or GetScenarioValue( "#combiH" ) == 3 then
				return true;
			end
		end
	end

	return false;
end

-------------------------------------------------------------------------------

function AchievementChecker:ID62()
	local	i, obj;
	local	c	= 0;

	--泥棒教師：アジトカスタマイズ用のアイテムを半分取得しました。
	for i = 0,99 do
		obj	= GetDB( "@ID_HASOBJS", 0, i );
		if not obj then
			break;
		end
		if obj > 0 then
			c	= c + 1;
		end
	end

	return c >= 30;
end

-------------------------------------------------------------------------------

function AchievementChecker:ID63()
	local	i, obj;

	--怪盗教師：アジトカスタマイズ用のアイテムをすべて取得しました。
	for i = 0,99 do
		obj	= GetDB( "@ID_HASOBJS", 0, i );
		if not obj then
			break;
		end
		if obj <= 0 then
			return false;
		end
	end
	
	return true;
end

-------------------------------------------------------------------------------

function AchievementChecker:ID64()
	--どこかで見た誰か：「沙耶の人形」を手に入れました。牝教師１・２、好評発売中！
	return GetDB( "@ID_HASOBJS", 0, "等身大フィギュア" ) >= 1;
end

-------------------------------------------------------------------------------

function AchievementChecker:ID69()
	--伝説の調教師：鑑賞室内のすべての隠し要素を解禁しました。
	return GetMuseumAchievementRate( "cg" ) >= 100 and GetMuseumAchievementRate( "scene" ) >= 100 and GetMuseumAchievementRate( "strip" ) >= 100;
end
