--[[
###############################################################################

                                特別授業SLG
                             1日の結果画面定義

                             ***** 注意 *****
               許可なく本ファイルの内容を変更しないで下さい。
         許可なく変更した結果については全て自己責任でお願いします。

###############################################################################
]]

day_result	= day_result or {
	base		= DIB.Create( "ec_day_base", 1, 0, 176 );
	chbase		= {
		DIB.Create( "ec_day_base_1", 1, 0, 225 ),
		DIB.Create( "ec_day_base_2", 1, 0, 343 ),
		DIB.Create( "ec_day_base_3", 1, 0, 460 )
	};
	notice		= DIB.Create( "ec_day_base_bar", 1, 0, 304 );
	font1		= DIB.Create( "ec_day_num" );
	font2		= DIB.Create( "ec_day_num2" );
	flare		= DIB.Create( "ec_flare", 120 );
	font		= DIBText.CreateFont( "ＭＳ　明朝", 14 );

	init		= false;
	forcedexit	= 0;
	progress	= 0;
	
	begin_prm	= {};
	end_prm		= {};
	delta_prm	= {};
	
	unlocks		= {};
	
	state		= -1;
};

---------------------------------------------------------------------------

function day_result:initialize( target )
	--初回のみ実行
	if self.init == false then
		DIBSetView( self.font1, 10, 10, 16, 26 );
		DIBSetView( self.font2, 10, 10, 10, 21 );
		self.init	= true;
	end

	SetSysButtonShortcut( false );

	--毎回実行

	--パラメータ変化のチェック
	local	bt_prm		= PrivateData["begin-time parameters"];
	local	db_name		= "#ID_BP";
	local	ch_name		= { "早紀", "ありさ", "美香子" };
	local	param_name	= { "口感度", "胸感度", "性器感度", "尻感度", "肌感度", "従順度", "調教受容度" };

	if not bt_prm then
		InitBeginTimeParameters();
		bt_prm		= PrivateData["begin-time parameters"];
	end

	self.begin_prm	= bt_prm;

	for ch,name in ipairs( ch_name ) do
		local	p	= self.end_prm[ch] and self.end_prm[ch] or {};
		local	d	= self.delta_prm[ch] and self.delta_prm[ch] or {};
		for prm,pname in ipairs( param_name ) do
			local	v	= GetDB( db_name, name, pname );
			p[prm]	= v;
			d[prm]	= v - self.begin_prm[ch][prm];
		end
		self.end_prm[ch]	= p;
		self.delta_prm[ch]	= d;
	end

	--調教開放チェック
	local	bt_count	= PrivateData["begin-time counters"];
	local	action_count, set_count;
	local	wstr;
	
	if not bt_count then
		InitBeginTimeCounters();
		bt_count	= PrivateData["begin-time counters"];
	end

	for ch,name in ipairs( ch_name ) do
		action_count		= 0;
		set_count			= 0;
		self.unlocks[ch]	= "";
		for k,v in ipairs( bt_count[ch] ) do
			if GetDB( "#ID_TC", ch - 1, v ) == 0 then
				for kk,vv in ipairs( var_playlist[ch] ) do
					if vv.index == v then
						wstr = self.unlocks[ch];
						if action_count > 0 then
							wstr = wstr .. "、";
						end
						wstr = wstr .. translate(vv["行為名"]);
						if #wstr <= 90 then
							self.unlocks[ch]	= wstr;
							set_count	= set_count + 1;
						end
						action_count	= action_count + 1;
						break;
					end
				end
			end
		end
		if set_count < action_count then
			self.unlocks[ch] = self.unlocks[ch] .. "ほか" .. ( action_count - set_count ) .. "行為" ;
		end
	end

	--演出準備
	self.forcedexit	= os.clock();
	self.progress	= 0;
	self.state		= 0;
	
	self:draw( target );
	
	return true;
end

---------------------------------------------------------------------------

function day_result:update( mx, my )
	if self.forcedexit > 0 then
		if self.state == 0 then
			self.forcedexit	= os.clock();
			self.state	= 1;
		else
			self.progress	= os.clock() - self.forcedexit;
			if self.state == 1 then
				if self.progress >= 1.0 then
					self.state	= 2;
				end
				return 125, true;
			elseif self.state == 2 then
				if self.progress >= 8.0 then
					PushKey( "A" );
					self.forcedexit	= 0;
				elseif self.progress < 3.0 then
					DIBSetState( self.flare, ( self.progress - 1 ) * 60.0 );
					return 125, true;
				end
			end
		end
	end
	return 125, false;
end

---------------------------------------------------------------------------

function day_result:draw( target )
	--基本
	DrawObject( target );
	DIBCopy( target, 0, 0, self.base );

	local	x_ary	= {
		442 + 106 * 0,
		442 + 106 * 1,
		442 + 106 * 2,
		442 + 106 * 3,
		442 + 106 * 4,
		987 + 117 * 0,
		987 + 117 * 1
	};

	if self.state == 0 then
		return;
	elseif self.state == 1 then
		local	dx	= 0;
		local	delta= self.progress;
		local	prm	= self.begin_prm;
		
		if delta < 1.0 then
			dx	= math.pow( 1 - delta, 4.5 ) * 1366;
		end

		for k,v in ipairs( self.chbase ) do
			local	ch	= k - 1;
			local	y	= ch * 117 + 250;
			DIBCopy( target, dx, 0, v );
			for i,x in ipairs( x_ary ) do
				DrawAsciiText( target, x + dx, y, string.format( "%3d", prm[k][i] ), self.font1 );
			end
		end
	else
		local	prm	= self.end_prm;
		local	dlt	= self.delta_prm;
		for k,v in ipairs( self.chbase ) do
			local	ch	= k - 1;
			local	y	= ch * 117 + 250;
			DIBCopy( target, 0, 0, v );
			for i,x in ipairs( x_ary ) do
				DrawAsciiText( target, x, y, string.format( "%3d", prm[k][i] ), self.font1 );
				if dlt[k][i] ~= 0 then
					if i == 7 then
						x	= x + 16;
					end
					DrawAsciiText( target, x + 48, y + 5, string.format( "(%+2d)", dlt[k][i] ), self.font2, dlt[k][i] > 0 and 0 or 0xffff0000 );
					DIBCopy( target, x - 5, y - 42, self.flare );
				end
			end
			if #self.unlocks[k] > 0 then
				DIBCopy( target, 0, ch * 117, self.notice );
				DrawText( target, 450, ch * 117 + 304 + 8, self.font, translate(self.unlocks[k]) );
			end
		end
	end
end

---------------------------------------------------------------------------

function day_result:doaction( key )
	if key == KEY_A or key == KEY_B then
		local	bt_prm	= PrivateData["begin-time parameters"];

		for ch,name_ary in ipairs( self.end_prm ) do
			for prm,p in ipairs( name_ary ) do
				bt_prm[ch][prm]	= p;
			end
		end
		
		UpdateBeginTimeCounters();
	end
	return true;
end

---------------------------------------------------------------------------

function day_result:rebuild( target, state )
	self:draw( target );
end

---------------------------------------------------------------------------

function InitBeginTimeParameters()
	local	bt_prm		= PrivateData["begin-time parameters"];
	local	db_name		= "#ID_BP";
	local	ch_name		= { "早紀", "ありさ", "美香子" };
	local	param_name	= { "口感度", "胸感度", "性器感度", "尻感度", "肌感度", "従順度", "調教受容度" };

	if not bt_prm then
		bt_prm	= {};
		PrivateData["begin-time parameters"]	= bt_prm;
	end

	for ch,name in ipairs( ch_name ) do
		local	p	= bt_prm[ch] and bt_prm[ch] or {};
		for prm,pname in ipairs( param_name ) do
			p[prm]	= GetDB( db_name, name, pname );
		end
		bt_prm[ch]	= p;
	end
end

---------------------------------------------------------------------------

function InitBeginTimeCounters()
	local	bt_count	= PrivateData["begin-time counters"];
	local	db_name		= "#ID_TC";
	local	ch_name		= { "早紀", "ありさ", "美香子" };
	local	v;
	
	if not bt_count then
		bt_count	= {};
		PrivateData["begin-time counters"]	= bt_count;
	end

	for ch,name in ipairs( ch_name ) do
		local	p	= {};
		for i = 0,100 do
			v	= GetDB( db_name, ch - 1, i );
			if v == -1 then
				table.insert( p, i );
			end
		end
		bt_count[ch]	= p;
	end
end

---------------------------------------------------------------------------

function UpdateBeginTimeCounters()
	local	bt_count	= PrivateData["begin-time counters"];
	local	db_name		= "#ID_TC";
	local	ch_name		= { "早紀", "ありさ", "美香子" };
	
	for ch,name in ipairs( ch_name ) do
		local	p	= {};
		for k,v in ipairs( bt_count[ch] ) do
			if GetDB( db_name, ch - 1, v ) < 0 then
				table.insert( p, v );
			end
		end
		bt_count[ch]	= p;
	end
--[[
	local	str	= "";
	for k,v in ipairs( bt_count ) do
		str	= str .. k .. ": ";
		for kk,vv in ipairs( v ) do
			str	= str .. vv .. ",";
		end
		str	= str .. "\n";
	end
	print( str );
--]]
end

---------------------------------------------------------------------------

function CancelDayResult()
	InitBeginTimeParameters();
	UpdateBeginTimeCounters();
end

---------------------------------------------------------------------------

function AddCorrectionValue( name )
	if GetDB( "#ID_BP", name, "調教進行度" ) < 100 then
		AddDB( "#ID_BP", name, "従順度", GetDB( "@アジト補正", 0, "従順度" ), -50, 255 );
		AddDB( "#ID_BP", name, "調教受容度", GetDB( "@アジト補正", 0, "調教受容度" ), -255, 255 );
	end
end
