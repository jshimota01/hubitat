--[[
###############################################################################

                                特別授業SLG
                             通常調教準備画面

                             ***** 注意 *****
               許可なく本ファイルの内容を変更しないで下さい。
         許可なく変更した結果については全て自己責任でお願いします。

###############################################################################
]]

var_playlist	= var_playlist or {
	OpenCSVDB( "var_playlist1" );
	OpenCSVDB( "var_playlist2" );
	OpenCSVDB( "var_playlist3" );
};

training	= training or {
	target_no	= 0;
	begin_time	= 0;

	progress_base= DIB.Create( "tra_progress", 1, 0, 25 );
	menu_base	= DIB.Create( "tra_menu_base", 1, 460, 70 );
	menu_bar	= ScrollBar:New( "tra_menu_bar", 1323, 112, 18, 14 );
	menu_item	= DIB.Create( "tra_menu_item" );
	result_base	= DIB.Create( "tra_result_base", 1, 12, 550 );
	enter		= DIB.Create( "tra_enter", 2, 1059, 0 );
	help		= DIB.Create( "help", 2, 1248, 642 );
	item_remove	= DIB.Create( "item_remove", 2, 400, 597 );
	detail_base	= DIB.Create( "tra_detail_base", 1, 12, 396 );
	detail_notes= DIB.Create( "tra_detail_notes", 1, 172, 518 );

	font		= DIBText.CreateFont( "ＭＳ　明朝", 14 );
	ascfont		= DIB.Create( "asciifont" );

	number_font	= DIB.Create( "tra_num", 10 );
	
	is_slave	= false;
	level		= {};

	cur_playlist= {};
	base_param	= {};
	cur_param	= {};
	param_cor	= {};
	is_disableBT	= false;
	is_disableCSA	= false;
	is_disableFO	= false;

	select_no	= -1;
	enter_pos	= 0;
	help_page	= 0;
	help_screen	= false;
	help_button	= false;
	
	graph_check	= {
		{ enable = true, img = DIB.Create( "tra_checkf00", 1, 935+144*0, 609+math.floor(26.5*0) ), region = { 928+144*0, 602+math.floor(25.5*0), 27+21*3, 26 } },
		{ enable = true, img = DIB.Create( "tra_check00f", 1, 935+144*0, 609+math.floor(26.5*1) ), region = { 928+144*0, 602+math.floor(25.5*1), 27+21*5, 26 } },
		{ enable = true, img = DIB.Create( "tra_check0f0", 1, 935+144*1, 609+math.floor(26.5*0) ), region = { 928+144*1, 602+math.floor(25.5*0), 27+21*3, 26 } },
		{ enable = true, img = DIB.Create( "tra_check070", 1, 935+144*1, 609+math.floor(26.5*1) ), region = { 928+144*1, 602+math.floor(25.5*1), 27+21*3, 26 } },
		{ enable = true, img = DIB.Create( "tra_check0ff", 1, 935+144*1, 609+math.floor(26.5*2) ), region = { 928+144*1, 602+math.floor(25.5*2), 27+21*4, 26 } },
		{ enable = true, img = DIB.Create( "tra_check077", 1, 935+144*1, 609+math.floor(26.5*3) ), region = { 928+144*1, 602+math.floor(25.5*3), 27+21*3, 26 } },
		{ enable = true, img = DIB.Create( "tra_checkf70", 1, 935+144*1, 609+math.floor(26.5*4) ), region = { 928+144*1, 602+math.floor(25.5*4), 27+21*3, 26 } },
		{ enable = true, img = DIB.Create( "tra_checkff0", 1, 935+144*0, 609+math.floor(26.5*2) ), region = { 928+144*0, 602+math.floor(25.5*2), 27+21*2, 26 } },
		{ enable = true, img = DIB.Create( "tra_checkf0f", 1, 935+144*0, 609+math.floor(26.5*3) ), region = { 928+144*0, 602+math.floor(25.5*3), 27+21*2, 26 } },
	};
	
	detail_param= {
		{ { 0, "0", 0 }, { 0, "0", 0 }, { 0, "0", 0 }, { 0, "0", 0 }, { 0, "0", 0 }, { 0, "0", 0 }, { 0, "0", 0 }, { 0, "0", 0 }, { 0, "0", 0 } },
		{ { 0, "0", 0 }, { 0, "0", 0 }, { 0, "0", 0 }, { 0, "0", 0 }, { 0, "0", 0 }, { 0, "0", 0 }, { 0, "0", 0 }, { 0, "0", 0 }, { 0, "0", 0 } },
	};

	init		= false;
};

---------------------------------------------------------------------------
function training:InitBaseParameter()
	local	target_no	= self.target_no - 1;

	if target_no < 0 or target_no > 2 then
		return false;
	end

	local	prm_name	= { "調教進行度", "従順度", "調教受容度", "口感度", "胸感度", "性器感度", "尻感度", "肌感度", "BT値", "BT値上昇率", "気力", "状態" };

	for k,v in ipairs( prm_name ) do
		self.base_param[v]	= GetDB( "#ID_BP", target_no, v );
	end

	local	lv	= self.base_param["調教進行度"];
	
	self.is_slave	= lv >= 100;
	
	for i = 1,3 do
		self.level[i]	= math.floor( lv % 10 );
		lv	= math.floor( lv / 10 );
		if lv == 0 then
			for i = i+1,3 do
				self.level[i]	= -1;
			end
			break;
		end
	end

	--detail
	self:CalcDetailParameter( self.detail_param[1], self.base_param );

	return true;
end

---------------------------------------------------------------------------
function training:InitCurrentParameter()
	for k,v in pairs( self.base_param ) do
		self.cur_param[k]	= v;
	end

	--detail
	self:CalcDetailParameter( self.detail_param[2], self.cur_param );

	return true;
end

---------------------------------------------------------------------------
function training:InitParameterCorrection()
	self.param_cor["従順度"]	= 100;
	self.param_cor["調教受容度"]= 100;
	self.param_cor["口感度"]	= GetDB( "@ID_TERCOR", 0, "口感度" );
	self.param_cor["胸感度"]	= GetDB( "@ID_TERCOR", 0, "胸感度" );
	self.param_cor["性器感度"]	= GetDB( "@ID_TERCOR", 0, "性器感度" );
	self.param_cor["尻感度"]	= GetDB( "@ID_TERCOR", 0, "尻感度" );
	self.param_cor["肌感度"]	= GetDB( "@ID_TERCOR", 0, "肌感度" );
	self.param_cor["BT値"]		= GetDB( "@ID_TERCOR", 0, "BT値" ) + self.base_param["BT値上昇率"];
	self.param_cor["気力"]		= GetDB( "@ID_TERCOR", 0, "気力" );

	local	state	= GetDB( "@ID_TERCOR", 0, "状態" );
	self.is_disableBT	= bit32.btest( state, bit32.lshift( 0x1, 0 ) );	--ぶっ飛び無効
	self.is_disableCSA	= bit32.btest( state, bit32.lshift( 0x1, 1 ) );	--同一行為補正無効
	self.is_disableFO	= bit32.btest( state, bit32.lshift( 0x1, 2 ) );	--調教時従順度不動

	return true;
end

---------------------------------------------------------------------------
function training:UpdatePlaylist()
	local	target_no	= self.target_no;

	if target_no < 1 or target_no > 3 then
		return false;
	end

	--初期化
	self.cur_playlist	= {};

	local	recipe			= PrivateData["play_recipe"];
	local	cur_playlist	= self.cur_playlist;
	local	is_night		= GetScenarioValue( "#time" );
	local	is_first_play	= true;
	
	for k,v in ipairs( recipe ) do
		if v then
			is_night	= is_night + 1;
		end
	end
	is_night	= is_night >= 7;

	for k,v in ipairs( recipe ) do
		if v then
			--有効な行為が設定されているなら
			is_first_play	= false;
			break;
		end
	end

	for k,v in ipairs( var_playlist[target_no] ) do
		local	index	= v.index;
		local	count	= GetDB( "#ID_TC", target_no - 1, index );
		if count >= 0 then
			local	play	= {};
			for kk,vv in pairs( v ) do
				play[kk]	= vv;
			end
			play["can_select"]	= ( not v["時間帯"] or ( v["時間帯"] == "夜" and is_night ) ) and ( not v["単一選択"] or ( v["単一選択"] and is_first_play ) );
			play["is_new"]		= count == 0;
			cur_playlist[#cur_playlist + 1]	= play;
		end
	end

	--補正値適用
	local	energy		= self.cur_param["気力"];
	local	energy_mod	= ( energy - 100 ) * 0.05;
	local	cur_juyoudo	= self.cur_param["調教受容度"];
	local	status		= PrivateData["play_status"];

	for k,v in ipairs( cur_playlist ) do
		local	class	= v["系統"];
		local	lv		= v["Lv"];
		local	juyoudo	= 0;

		if class == "変態" then
			if cur_juyoudo <= 0 then
				juyoudo	= lv == "Soft" and 4 or 6;
			else
				juyoudo	= lv == "Soft" and -4 or -6;
			end
		else
			local	delta	= 0;

			if class == "快楽" then
				delta	= lv == "Soft" and 3 or 4;
			elseif class == "奉仕" then
				delta	= lv == "Soft" and 1 or 2;
			elseif class == "退廃" then
				delta	= lv == "Soft" and -1 or -2;
			elseif class == "嗜虐" then
				delta	= lv == "Soft" and -3 or -4;
			end

			if delta ~= 0 then
				if cur_juyoudo <= -170 then
					juyoudo	= ( delta * -2 + 3 ) * -1;
				elseif cur_juyoudo < 170 then
					juyoudo	= delta;
				else
					juyoudo	= delta * 2 + 3;
				end
			end
		end

		--気絶
		if energy <= 0 then
			v["従順度"]		= 0;
			v["調教受容度"]	= 0;
			v["口感度"]		= 0;
			v["胸感度"]		= 0;
			v["性器感度"]	= 0;
			v["尻感度"]		= 0;
			v["肌感度"]		= 0;
			v["BT値"]		= 0;
		else
			v["従順度"]		= math.floor( ( self.param_cor["従順度"] / 100 ) * v["従順度"] );
			v["調教受容度"]	= math.floor( ( self.param_cor["調教受容度"] / 100 ) * juyoudo );
			v["口感度"]		= math.floor( ( self.param_cor["口感度"] / 100 ) * v["口感度"] );
			v["胸感度"]		= math.floor( ( self.param_cor["胸感度"] / 100 ) * v["胸感度"] );
			v["性器感度"]	= math.floor( ( self.param_cor["性器感度"] / 100 ) * v["性器感度"] );
			v["尻感度"]		= math.floor( ( self.param_cor["尻感度"] / 100 ) * v["尻感度"] );
			v["肌感度"]		= math.floor( ( self.param_cor["肌感度"] / 100 ) * v["肌感度"] );
			v["BT値"]		= math.floor( ( self.param_cor["BT値"] / 100 ) * v["BT値"] );

			--まぐろ
			if energy <= 30 then
				v["従順度"]		= math.floor( v["従順度"] / 2 );
				v["調教受容度"]	= math.floor( v["調教受容度"] / 2 );
				v["口感度"]		= math.floor( v["口感度"] / 2 );
				v["胸感度"]		= math.floor( v["胸感度"] / 2 );
				v["性器感度"]	= math.floor( v["性器感度"] / 2 );
				v["尻感度"]		= math.floor( v["尻感度"] / 2 );
				v["肌感度"]		= math.floor( v["肌感度"] / 2 );
				v["BT値"]		= math.floor( v["BT値"] / 2 );
			end
		end
		if v["気力"] < 0 then
			v["気力"]		= math.floor( ( self.param_cor["気力"] / 100 ) * v["気力"] + energy_mod );
		end

		--同行為？同系統？
		local	prev_play	= status.prev_play[v["index"]];
		if prev_play then
			if not self.is_disableCSA then
				if class ~= "その他" then
					v["従順度"]		= v["従順度"] - prev_play;
				end
				v["口感度"]		= math.floor( v["口感度"] / prev_play );
				v["胸感度"]		= math.floor( v["胸感度"] / prev_play );
				v["性器感度"]	= math.floor( v["性器感度"] / prev_play );
				v["尻感度"]		= math.floor( v["尻感度"] / prev_play );
				v["肌感度"]		= math.floor( v["肌感度"] / prev_play );
				v["BT値"]		= math.floor( v["BT値"] / prev_play );
			end
		elseif class == status.prev_class then
			v["口感度"]		= math.floor( v["口感度"] * 1.2 );
			v["胸感度"]		= math.floor( v["胸感度"] * 1.2 );
			v["性器感度"]	= math.floor( v["性器感度"] * 1.2 );
			v["尻感度"]		= math.floor( v["尻感度"] * 1.2 );
			v["肌感度"]		= math.floor( v["肌感度"] * 1.2 );
			v["BT値"]		= math.floor( v["BT値"] * 1.2 );
		end

		--隷属したら従順度と調教受容度は変化しない
		if self.is_slave then
			v["従順度"]		= 0;
			v["調教受容度"]	= 0;
		elseif self.is_disableFO then
			v["従順度"]		= 0;
		end
	end

	self.menu_bar:ResetItems( #self.cur_playlist );

	return true;
end

---------------------------------------------------------------------------
function training:AddRecipe( index )
	local	recipe	= PrivateData["play_recipe"];

	if not index then
		recipe[#recipe + 1]	= false;
		return true;
	end

	if #recipe >= 5 then
		return false;
	end

	local	play	= self:PlayFromIndex( index );
	if not play then
		return false;
	end

	local	p	= {};
	for k,v in pairs( play ) do
		p[k]	= v;
	end
	p["state_color"]	= 0;
	if self.cur_param["気力"] < 30 then
		p["state_color"]	= self.cur_param["気力"] < 0 and 0xffff0000 or 0xffffff00;
	end
	recipe[#recipe + 1]	= p;

	local	param_cor	= self.param_cor;
	param_cor["BT値"]	= param_cor["BT値"] + self.base_param["BT値上昇率"];

	local	status	= PrivateData["play_status"];
	local	index	= play["index"];

	if not status.prev_play[index] then
		status.prev_play[index]	= 0;
	end
	status.prev_play[index] = status.prev_play[index] + 1;
	status.prev_class	= play["系統"];
	status.play_count	= status.play_count + 1;

	local	prms	= {
		{ "従順度", -50, 255 },
		{ "調教受容度", -255, 255 },
		{ "口感度", 0, 999 },
		{ "胸感度", 0, 999 },
		{ "性器感度", 0, 999 },
		{ "尻感度", 0, 999 },
		{ "肌感度", 0, 999 },
		{ "BT値", 0, 100 },
		{ "気力", -30, 100 },
	};
	local	src		= recipe[#recipe];
	local	dest	= self.cur_param;

	for k,v in pairs( prms ) do
		local	val	= dest[v[1]] + src[v[1]];
		if val < v[2] then val = v[2] elseif val > v[3] then val = v[3] end
		dest[v[1]]	= val;
	end

	if play["単一選択"] then
		for i = #recipe + 1,5 do
			recipe[i]	= false;
		end
	end

	self:UpdatePlaylist();
	
	return true;
end

---------------------------------------------------------------------------
function training:RefreshResult()
	local	recipe	= PrivateData["play_recipe"];
	local	indexs	= {};

	local	status	= PrivateData["play_status"];
	status.prev_play	= {};
	status.prev_class	= 0;
	status.play_count	= 0;
	
	for k,v in ipairs( recipe ) do
		if type( v ) == "table" then
			table.insert( indexs, v.index );
		else
			table.insert( indexs, -1 );
		end
	end

	self:InitCurrentParameter();
	self:InitParameterCorrection();
	self:UpdatePlaylist();

	PrivateData["play_recipe"]	= {};
	if #indexs > 0 then
		for k,v in ipairs( indexs ) do
			if v == -1 then
				table.insert( PrivateData["play_recipe"], false );
				self:UpdatePlaylist();
			else
				self:AddRecipe( v );
			end
		end
	end

	--detail
	self:CalcDetailParameter( self.detail_param[2], self.cur_param );

	return false;
end

---------------------------------------------------------------------------
function training:TableNoToIndex( no )
	return self.cur_playlist[no].index;
end

---------------------------------------------------------------------------
function training:PlayFromIndex( index )
	for k,v in ipairs( self.cur_playlist ) do
		if v.index == index and v.can_select then
			return v;
		end
	end
	return nil;
end

---------------------------------------------------------------------------
function training:DrawLine( target, playlist, param_name, color, min, max, ratio, base_height )
	local	x, y	= 485, 727;
	local	val, val2;
	local	base_value	= self.base_param[param_name];

	ratio		= ratio or 1.0;
	base_height	= base_height or 0;

	val	= math.floor( base_value * ratio + 0.5 + base_height );
	if val < 0 then val = -1 elseif val > 100 then val = 100 end
	DrawLine( target, x, y - val, x + 26, y - val, color );
	x	= x + 26;

	for k,v in ipairs( playlist ) do
		local	nx	= x + 64;
		local	nv	= v ~= false and v[param_name] or 0;
		val	= math.floor( base_value * ratio + 0.5 + base_height );
		val2= math.floor( ( base_value + nv ) * ratio + 0.5 + base_height );
		if val < 0 then val = -1 elseif val > 100 then val = 100 end
		if val2< 0 then val2= -1 elseif val2> 100 then val2= 100 end
		DrawLine( target, x, y - val, nx, y - val2, color );
		base_value	= base_value + nv;
		if base_value < min then base_value = min elseif base_value > max then base_value = max end
		x	= nx;
	end

	val	= math.floor( base_value * ratio + 0.5 + base_height );
	if val < 0 then val = -1 elseif val > 100 then val = 100 end
	DrawLine( target, x, y - val, 859, y - val, color );
	
	return base_value;
end

---------------------------------------------------------------------------
function training:CalcDetailParameter( detail, param )
	local	v, c;

	v	= param["従順度"];
	detail[1][1]	= 80;
	detail[1][2]	= string.format( "%3d", v );
	detail[1][3]	= v < 0 and 0xffff0000 or 0;

	v	= param["調教受容度"];
	c	= 0;
	if v > 85 then
		c	= 0xffff66aa;
	elseif v < -85 then
		c	= 0xffaa66ff;
	end
	detail[2][1]	= 117;
	detail[2][2]	= string.format( "%4d", v );
	detail[2][3]	= c;

	local	str	= { "口感度", "胸感度", "性器感度", "尻感度", "肌感度" };
	for k,v in ipairs( str ) do
		v	= param[v];
		detail[2 + k][1]	= 170 + 40 * ( k - 1 );
		detail[2 + k][2]	= string.format( "%3d", v );
		detail[2 + k][3]	= 0;
	end

	v	= param["BT値"];
	detail[8][1]	= 370;
	detail[8][2]	= string.format( "%3d", v );
	detail[8][3]	= v >= 100 and 0xffff0000 or 0;

	v	= param["気力"];
	c	= 0;
	if v < 0 then
		c	= 0xffff0000;
	elseif v < 30 then
		c	= 0xffffff00;
	end
	detail[9][1]	= 410;
	detail[9][2]	= string.format( "%3d", v );
	detail[9][3]	= c;
end

---------------------------------------------------------------------------
function training:initialize( target )
	if self.init == false then
		self.init	= true;
	end

	SetSysButtonShortcut( false );

	self.target_no	= GetScenarioValue( "#training_target" );
	self.begin_time	= GetScenarioValue( "#training_time" );
	self.help_page	= 0;

	PrivateData["play_status"]	= PrivateData["play_status"] or {};
	local	status	= PrivateData["play_status"];
	status.target_no	= self.target_no;
	status.next_time	= self.begin_time;
	status.prev_play	= {};
	status.prev_class	= 0;
	status.play_count	= 0;

	local	recipe	= {};
	for i = 1,self.begin_time - 1 do
		recipe[i]	= false;
	end
	PrivateData["play_recipe"]	= recipe;

	if not self:InitBaseParameter()
	or not self:InitCurrentParameter()
	or not self:InitParameterCorrection()
	or not self:UpdatePlaylist() then
		return false;
	end

	DIBSetState( self.help, 0 );
	DIBSetState( self.enter, 0 );

	self.menu_bar:Init( #self.cur_playlist );

	self:draw( target );

	return true;
end

---------------------------------------------------------------------------

function training:update( mx, my )
	-- open help
	if self.help_page > 0 then
		if self.is_update then
			self.is_update	= false;
			return -2, false;
		end

		self.select_no	= -1;
		
		local	x	= self.help_page == 1 and 1088 or 1051;
		DIBSetState( self.help_button, 0 );
		if mx >= x and mx < x + DIBGetWidth( self.help_button ) and my >= 32 and my < 32 + DIBGetHeight( self.help_button ) then
			DIBSetState( self.help_button, 1 );
			self.select_no	= 0;
		end
		return self.select_no, false;
	end
	
	local	forced_refresh	= UpdateObject();

	if self.is_update then
		self.is_update	= false;
		return -2, forced_refresh;
	end

	self.select_no	= -1;
	
	--menu item
	for i = 0, 13 do
		local	y	= 32 * i + 112;
		if mx >= 480 and mx < 480 + 837 and my >= y and my < y + 32 then
			self.select_no	= i;
			break;
		end
	end

	--menu bar
	if self.menu_bar:Update( mx, my ) then;
		forced_refresh	= true;
	end

	--result
	for k,v in ipairs( PrivateData["play_recipe"] ) do
		local	no	= k - 1;
		if type( v ) == "table" and mx >= 389 and mx < 389 + 32 and my >= no * 32 + 592 and my < no * 32 + 592 + 32 then
			self.select_no	= 40 + no;
		end
	end

	for k,v in ipairs( self.graph_check ) do
		if mx >= v.region[1] and mx < v.region[1] + v.region[3] and my >= v.region[2] and my < v.region[2] + v.region[4] then
			self.select_no	= 19 + k;
		end
	end

	--help
	DIBSetState( self.help, 0 );
	if mx >= 1248 and mx < 1248 + DIBGetWidth( self.help ) and my >= 642 and my < 642 + DIBGetHeight( self.help ) / 2 then
		DIBSetState( self.help, 1 );
		self.select_no	= 123;
	end
	
	--enter
	DIBSetState( self.enter, 0 );
	if PrivateData["play_status"]["play_count"] > 0 then
		if mx >= 1059 and mx < 1059 + DIBGetWidth( self.enter ) and my >= 0 and my < DIBGetHeight( self.enter ) / 2 then
			DIBSetState( self.enter, 1 );
			self.select_no	= 64;
		end
	end

	if self.enter_pos < 0 then
		self.enter_pos	= self.enter_pos * 0.9;
		if self.enter_pos > -0.001 then
			self.enter_pos	= 0;
		end

		return self.select_no, true;
	end

	return self.select_no, forced_refresh;
end

---------------------------------------------------------------------------

function training:draw( target )
	
	-- open help
	if self.help_page > 0 then
		DIBCopy( target, 0, 0, self.help_screen );
		DIBCopy( target, 0, 0, self.help_button );
		return;
	end

	DrawObject( target );

	--detail parameters
	DIBCopy( target, 0, 0, self.detail_base );
	for k,v in ipairs( self.detail_param ) do
		for k2,v2 in ipairs( v ) do
			DrawAsciiText( target, v2[1], 384 + 53 * k, v2[2], self.ascfont, v2[3] );
		end
	end
	local	color	= GetDB( "#ID_BP", self.target_no - 1, "調教進行度" ) < 100 and 0 or 0xff888888;
	local	jujundo	= GetDB( "@ID_TERCOR", 0, "従順度" );
	DrawAsciiText( target, 80, 517, string.format( "%+3d", jujundo ), self.ascfont, ( color == 0 and jujundo < 0 ) and 0xffff0000 or color );
	DrawAsciiText( target,128, 517, string.format( "%+3d", GetDB( "@ID_TERCOR", 0, "調教受容度" ) ), self.ascfont, color );
	if color == 0 then
		DIBCopy( target, 0, 0, self.detail_notes );
	end

	--menu
	DIBCopy( target, 0, 0, self.menu_base );
	self.menu_bar:Draw( target );

	local	x, y		= 481, 113;
	local	playlist	= self.cur_playlist;
	local	base_line	= self.menu_bar.first_line + 1;

	for i = 0, 13 do
		local	play	= playlist[base_line + i];
		
		if play == nil then
			break;
		end
		
		local	can_select	= play["can_select"];
		local	yy			= i * 32 + y;
		local	color		= can_select and 0 or 0x80888888;

		DIBCopy( target, x, yy, self.menu_item );

		if play["is_new"] then
			DrawText( target, x -  32, yy + 6, self.font, "New", 0xffffff00 );
		end
		DrawText( target, x +   4, yy + 6, self.font, translate(play["行為名"]), color );
		DrawText( target, x + 254, yy + 6, self.font, translate(play["系統"]), color );
		
		if can_select then
			local	w;
			
			if play["従順度"] ~= 0 then		w = math.floor( play["従順度"] );		DrawAsciiText( target, x + 53 * 0 + 345, yy + 4, string.format( "%+3d", w ), self.ascfont, w > 0 and 0 or 0xffff0000 );	end
			if play["調教受容度"] ~= 0 then	w = math.floor( play["調教受容度"] );	DrawAsciiText( target, x + 53 * 1 + 345, yy + 4, string.format( "%+3d", w ), self.ascfont, w > 0 and 0 or 0xffff0000 );	end
			if play["口感度"] ~= 0 then		w = math.floor( play["口感度"] );		DrawAsciiText( target, x + 53 * 2 + 345, yy + 4, string.format( "%+3d", w ), self.ascfont, w > 0 and 0 or 0xffff0000 );	end
			if play["胸感度"] ~= 0 then		w = math.floor( play["胸感度"] );		DrawAsciiText( target, x + 53 * 3 + 345, yy + 4, string.format( "%+3d", w ), self.ascfont, w > 0 and 0 or 0xffff0000 );	end
			if play["性器感度"] ~= 0 then	w = math.floor( play["性器感度"] );		DrawAsciiText( target, x + 53 * 4 + 345, yy + 4, string.format( "%+3d", w ), self.ascfont, w > 0 and 0 or 0xffff0000 );	end
			if play["尻感度"] ~= 0 then		w = math.floor( play["尻感度"] );		DrawAsciiText( target, x + 53 * 5 + 345, yy + 4, string.format( "%+3d", w ), self.ascfont, w > 0 and 0 or 0xffff0000 );	end
			if play["肌感度"] ~= 0 then		w = math.floor( play["肌感度"] );		DrawAsciiText( target, x + 53 * 6 + 345, yy + 4, string.format( "%+3d", w ), self.ascfont, w > 0 and 0 or 0xffff0000 );	end
			if play["BT値"] ~= 0 then		w = math.floor( play["BT値"] );			DrawAsciiText( target, x + 64 * 0 + 719, yy + 4, string.format( "%+4d", w ), self.ascfont, w > 0 and 0 or 0xffff0000 );	end
			if play["気力"] ~= 0 then		w = math.floor( play["気力"] );			DrawAsciiText( target, x + 64 * 1 + 719, yy + 4, string.format( "%+4d", w ), self.ascfont, w > 0 and 0 or 0xffff0000 );	end
		end
	end
	if self.select_no >= 0 and self.select_no < 14 then
		DIBReverseColor( target, 480, 32 * self.select_no + 112, 837, 32 );
	end

	--result
	DIBCopy( target, 0, 0, self.result_base );

	local	enables	= {};

	for k,v in ipairs( self.graph_check ) do
		enables[k]	= v.enable;
		if v.enable then
			DIBCopy( target, 0, 0, v.img );
		end
	end

	local	recipe	= PrivateData["play_recipe"];

	x		= 60;

	for k,v in ipairs( recipe ) do
		local	by	=( k - 1 ) * 32;
		local	y	= by + 600;
		if v ~= false then
			local	color	= v["state_color"];
			DrawText( target, x +   4, y, self.font, translate(v["行為名"]), color );
			DrawText( target, x + 254, y, self.font, translate(v["系統"]), color );
			DIBSetState( self.item_remove, self.select_no == 39 + k and 1 or 0 );
			DIBCopy( target, 0, by, self.item_remove );
		else
			DrawText( target, x +   4, y, self.font, "----------------------" );
			DrawText( target, x + 254, y, self.font, "------" );
		end
	end

	local	p	= {};

	if enables[1] then p[1] = self:DrawLine( target, recipe, "従順度", 0xffff0000, -50, 255, 100/255 ); end
	if enables[2] then p[2] = self:DrawLine( target, recipe, "調教受容度", 0xff0000ff, -255, 255, 50/255, 50 ); end
	if enables[3] then p[3] = self:DrawLine( target, recipe, "口感度", 0xff00ff00, 0, 999, 100/999 ); end
	if enables[4] then p[4] = self:DrawLine( target, recipe, "胸感度", 0xff007f00, 0, 999, 100/999 ); end
	if enables[5] then p[5] = self:DrawLine( target, recipe, "性器感度", 0xff00ffff, 0, 999, 100/999 ); end
	if enables[6] then p[6] = self:DrawLine( target, recipe, "尻感度", 0xff007f7f, 0, 999, 100/999 ); end
	if enables[7] then p[7] = self:DrawLine( target, recipe, "肌感度", 0xffff7f00, 0, 999, 100/999 ); end
	if enables[8] then p[8] = self:DrawLine( target, recipe, "BT値", 0xffffff00, 0, 100 ); end
	if enables[9] then p[9] = self:DrawLine( target, recipe, "気力", 0xffff00ff, -30, 100 ); end

	--progress
	DIBCopy( target, 0, 0, self.progress_base );
	
	for i = 1,3 do
		local	v	= self.level[i];
		if v < 0 then
			break;
		end
		DIBSetState( self.number_font, v );
		DIBCopy( target, 326 - 40 * ( i - 1 ), 25, self.number_font );
	end

	--help
	DIBCopy( target, 0, 0, self.help );

	--enter
	if PrivateData["play_status"]["play_count"] > 0 then
		DIBCopy( target, self.enter_pos, 0, self.enter );
	end
end

---------------------------------------------------------------------------

function training:doaction( key )

	if key == KEY_A then
		local	select_no	= self.select_no;

		if self.help_page == 1 then
			if select_no == 0 then
				self.help_screen	= DIB.Create( "help_p2" );
				self.help_button	= DIB.Create( "help_b2", 2, 1051, 32 );
				self.help_page		= 2;
				self.is_update		= true;
			end
			return false;
		elseif self.help_page == 2 then
			if select_no == 0 then
				self.help_screen	= DIB.Create( "help_p1" );
				self.help_button	= DIB.Create( "help_b1", 2, 1088, 32 );
				self.help_page		= 1;
				self.is_update		= true;
			end
			return false;
		end
		--カスタマイズ画面を抜ける
		if select_no == 125 then
			return true;
		end

		local	recipe	= PrivateData["play_recipe"];

		--menu item
		if select_no >= 0 and select_no <= 13 then
			local	no	= select_no + self.menu_bar.first_line + 1;
			if self.cur_playlist[no]["can_select"] then
				if self:AddRecipe( self:TableNoToIndex( no ) ) then
					if PrivateData["play_status"]["play_count"] == 1 then
						self.enter_pos	= -266;
					end
					self:CalcDetailParameter( self.detail_param[2], self.cur_param );
					self.is_update	= true;
				end
			end
			return false;
		end

		--result check
		if select_no >= 20 and select_no < 30 then
			self.graph_check[select_no - 19].enable	= self.graph_check[select_no - 19].enable == false;
			self.is_update	= true;
		end

		if select_no >= 40 and select_no < 45 then
			local	no	= select_no - 39;
			if recipe[no]["単一選択"] then
				for i = no,5 do
					table.remove( recipe );
				end
			else
				table.remove( recipe, no );
			end
			self:RefreshResult();
			self.is_update	= true;
		end

		--help
		if select_no == 123 then
			self.help_screen	= DIB.Create( "help_p1" );
			self.help_button	= DIB.Create( "help_b1", 2, 1088, 32 );
			self.help_page		= 1;
			self.is_update		= true;
		end

		--enter
		if select_no == 64 then
			for i = #recipe + 1,5 do
				recipe[i]	= false;
			end
			return true;
		end
	elseif key == KEY_B then
		if self.help_page ~= 0 then
			self.help_page	= 0;
			self.is_update	= true;
		else
			local	recipe	= PrivateData["play_recipe"];
			local	first	= 0;
			for k,v in ipairs( recipe ) do
				if v then
					first	= k;
					break;
				end
			end
			if first > 0 then
				while first < #recipe and not recipe[#recipe] do
					table.remove( recipe );
				end
				table.remove( recipe );
				self:RefreshResult();
				self.is_update	= true;
			end
		end
	elseif key == KEY_WU then
		self.is_update	= self.menu_bar:ScrollUp();
		return true;
	elseif key == KEY_WD then
		self.is_update	= self.menu_bar:ScrollDown();
		return true;
	end

	return false;
end

---------------------------------------------------------------------------

function training:rebuild( target, state )
	self:draw( target );
end

---------------------------------------------------------------------------

function ResultTraining()

	if GetScenarioValue( "#scene_replay" ) > 0 then
		return;
	end

	local	status	= PrivateData["play_status"];

	if status == nil or status.next_time < 2 then
		return;
	end
	
	local	now_time= status.next_time - 1;
	local	recipe	= PrivateData["play_recipe"];

	if type( recipe ) ~= "table" or type( recipe[now_time] ) ~= "table" then
		return;
	end

	local	v		= recipe[now_time];
	local	chno	= status.target_no - 1;
	local	index	= v["index"];
	local	rate	= 1;

	if ( GetDB( "#ID_BP", chno, "BT値" ) + v["BT値"] ) >= 100 and not bit32.btest( GetDB( "@ID_TERCOR", 0, "状態" ), 0x1 ) then
		rate	= 2;
	end

	if GetDB( "#ID_BP", chno, "調教進行度" ) < 100 then
		AddDB( "#ID_BP", chno, "従順度", v["従順度"], -50, 255 );
		AddDB( "#ID_BP", chno, "調教受容度", v["調教受容度"], -255, 255 );
	end
	AddDB( "#ID_BP", chno, "口感度", v["口感度"] * rate, 0, 999 );
	AddDB( "#ID_BP", chno, "胸感度", v["胸感度"] * rate, 0, 999 );
	AddDB( "#ID_BP", chno, "性器感度", v["性器感度"] * rate, 0, 999 );
	AddDB( "#ID_BP", chno, "尻感度", v["尻感度"] * rate, 0, 999 );
	AddDB( "#ID_BP", chno, "肌感度", v["肌感度"] * rate, 0, 999 );
	AddDB( "#ID_BP", chno, "BT値", v["BT値"], 0, 100 );
	AddDB( "#ID_BP", chno, "気力", v["気力"], -30, 100 );

	--実行回数加算
	AddDB( "#ID_TC", chno, index, 1 );
	AddDB( "#ID_LOG", chno, "総調教回数", 1 );

	if v["系統"] == "快楽" then
		AddDB( "#ID_LOG", chno, "快楽系調教回数", 1 );
	elseif v["系統"] == "変態" then
		AddDB( "#ID_LOG", chno, "変態系調教回数", 1 );
	elseif v["系統"] == "退廃" then
		AddDB( "#ID_LOG", chno, "退廃系調教回数", 1 );
	elseif v["系統"] == "嗜虐" then
		AddDB( "#ID_LOG", chno, "嗜虐系調教回数", 1 );
	elseif v["系統"] == "奉仕" then
		AddDB( "#ID_LOG", chno, "奉仕系調教回数", 1 );
	else
		AddDB( "#ID_LOG", chno, "その他調教回数", 1 );
	end

	local	addlog	= v["ログ加算"];
	
	if addlog then
		local	tokens	= split( addlog );
		for k,v in pairs( tokens ) do
			AddDB( "#ID_LOG", chno, v, 1 );
		end
	end
end

---------------------------------------------------------------------------

function NextTraining( result )
	local	status	= PrivateData["play_status"];
	local	r		= 1;

	if status.next_time > 0 then
		local	recipe	= PrivateData["play_recipe"];

		for i = status.next_time,5 do
			local	v	= recipe[i];
			if type( v ) == "table" then
				ScenarioLabelCall( v["label"] );
				status.next_time	= i + 1;
				r	= 0;
				break;
			end
		end
	end

	if result then
		SetScenarioValue( result, r );
		if r ~= 0 then
			status.next_time	= 0;
		end
	end
end
