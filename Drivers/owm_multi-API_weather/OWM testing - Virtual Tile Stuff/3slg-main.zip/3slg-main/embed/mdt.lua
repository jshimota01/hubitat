--[[
###############################################################################

                                特別授業SLG
                               移動時間定義

                             ***** 注意 *****
               許可なく本ファイルの内容を変更しないで下さい。
         許可なく変更した結果については全て自己責任でお願いします。

###############################################################################
]]

mdt	= mdt or {
	base			= "map_date_base";
	base_pos		= { 780, 1 };

	ascfont			= DIB.Create( "asciifont" );
	day_no_max		= 0;
	dayno			= DIB.Create( "map_dayno", 7, 94, 15 );
};

---------------------------------------------------------------------------

function mdt:initialize()
	self.day_no_max	= tonumber( GetCFGString( GetCFGKey( "slot viewer" ), "day no max" ) );
end

---------------------------------------------------------------------------

function mdt:update( target, store )
	return false;
end

---------------------------------------------------------------------------

function mdt:draw( target, x, y )
	local	day		= GetScenarioValue( "#day" );	--
	local	time	= GetScenarioValue( "#time" );	--3~7

	x	= x + self.base_pos[1];
	y	= y + self.base_pos[2];

	DIBSetState( self.dayno, day % 7 );
	DIBCopy( target, x, y, self.dayno );

	day	= math.floor( day / 7 ) + 1;
	if self.day_no_max and self.day_no_max < day then
		day	= self.day_no_max;
	end
	
	DrawAsciiText( target, x + 42, y + 15, string.format( "%2d", day ), self.ascfont );
	DrawAsciiText( target, x + 41 + 192, y + 15, tostring( time - 2 ), self.ascfont );
end
