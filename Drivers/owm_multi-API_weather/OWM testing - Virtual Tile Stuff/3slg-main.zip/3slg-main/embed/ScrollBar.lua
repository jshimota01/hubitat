--[[
###############################################################################

                                ���ʎ���SLG
                             �X�N���[���o�[��`

                             ***** ���� *****
               ���Ȃ��{�t�@�C���̓��e��ύX���Ȃ��ŉ������B
         ���Ȃ��ύX�������ʂɂ��Ă͑S�Ď��ȐӔC�ł��肢���܂��B

###############################################################################
]]

ScrollBar	= {};

function ScrollBar:New( name, dx, dy, width, max_no )
	local	image	= DIB.Create( name, 1, dx, dy );
	
	if image == nil then
		return nil;
	end

	local	bar		= {};
	
	bar.image		= image;
	bar.dx			= dx;
	bar.dy			= dy;
	
	bar.view		= { 0, 0, DIBGetWidth( image ), DIBGetHeight( image ) };
	bar.view_height	= bar.view[4];
	bar.hit			= { dx, dy, dx + DIBGetWidth( image ), dy + DIBGetHeight( image ) };

	local	halfwidth	= math.floor( ( bar.view[3] + width ) / 2 );
	bar.hit[1]		= bar.hit[1] - halfwidth;
	bar.hit[3]		= bar.hit[3] + halfwidth;

	bar.first_line	= 0;
	bar.max_no		= max_no;
	bar.all_items	= 0;

	setmetatable( bar, { __index = ScrollBar } );

	return bar;
end

function ScrollBar:Init( all_items )
	local	rate	= self.max_no / all_items;
	if rate > 1 then
		rate	= 1;
	end
	self.view_height	= math.floor( DIBGetHeight( self.image ) * rate );
	self.view[2]		= 0;
	self.view[4]		= self.view_height;
	self.first_line		= 0;
	self.all_items		= all_items;
end

function ScrollBar:Update( mx, my )
	local	hit	= self.hit;

	if mx >= hit[1] and my >= hit[2] and mx < hit[3] and my < hit[4] and IsHitDecisionKey() then
		local	height		= DIBGetHeight( self.image );
		if self:UpdateBarArea( ( my - hit[2] ) / height ) then
			return true;
		end
	end
	
	return false;
end

function ScrollBar:Draw( target )
	DIBCopy( target, 0, self.view[2], self.image, self.view );
end

function ScrollBar:ResetItems( all_items )
	local	center_per	= 0;

	if self.all_items ~= 0 then
		center_per	= ( ( self.max_no / 2 ) + self.first_line ) / self.all_items;
	end

	self:Init( all_items );
	
	self.first_line	= -1;
	self:UpdateBarArea( center_per );
end

function ScrollBar:Scroll( new_first_line )
	local	all_items	= self.all_items;
	local	max_no		= self.max_no;
	local	first		= new_first_line;
	local	list_line	= false;

	if first < 0 or all_items <= max_no then
		first		= 0;
	elseif first >= all_items - max_no then
		first		= all_items - max_no;
		list_line	= true;
	end

	if self.first_line == first then
		return false;
	end

	local	height		= DIBGetHeight( self.image );

	self.view[2]	= math.floor( first / all_items * height );
	self.view[4]	= list_line and height - self.view[2] or self.view_height;
	self.first_line	= first;

	return true;
end

function ScrollBar:UpdateBarArea( center_per )
	local	all_items	= self.all_items;
	local	max_no		= self.max_no;
	return self:Scroll( math.floor( all_items * center_per ) - math.floor( max_no / 2 ) );
end

function ScrollBar:ScrollUp()
	return self:Scroll( self.first_line - 1 );
end

function ScrollBar:ScrollDown()
	return self:Scroll( self.first_line + 1 );
end
