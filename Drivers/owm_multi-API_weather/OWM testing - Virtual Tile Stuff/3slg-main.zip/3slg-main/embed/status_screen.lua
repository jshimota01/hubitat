--[[
###############################################################################

                                特別授業SLG
                            ステータス画面定義

                             ***** 注意 *****
               許可なく本ファイルの内容を変更しないで下さい。
         許可なく変更した結果については全て自己責任でお願いします。

###############################################################################
]]
status_screen	= status_screen or {
	select_no	= -1;
	is_update	= false;

	font		= DIBText.CreateFont( "ＭＳ　明朝", 14 );
	ascfont		= DIB.Create( "asciifont" );
	ascfont_s	= DIB.Create( "asciifont_s" );
	modes		= {};
	mode		= 1;

	tc_bar		= {
		ScrollBar:New( "status_tbar", 672 + 342 * 0, 144, 24, 18 ),
		ScrollBar:New( "status_tbar", 672 + 342 * 1, 144, 24, 18 ),
		ScrollBar:New( "status_tbar", 672 + 342 * 2, 144, 24, 18 )
	};

	res_bar		= {
		ScrollBar:New( "status_tbar", 672 + 342 * 0, 144, 24, 18 ),
		ScrollBar:New( "status_tbar", 672 + 342 * 1, 144, 24, 18 ),
		ScrollBar:New( "status_tbar", 672 + 342 * 2, 144, 24, 18 )
	};

	achi_bar	= ScrollBar:New( "status_abar", 1312, 149, 24, 18 );

	base_names	= {
		"status_basic_base",
		"status_training_base",
		"status_training_base",
		"status_achievement_base"
	};
	mode_base	= false;

	titem_base	= {
		n	= DIB.Create( "status_titem_basen" ),
		m	= DIB.Create( "status_titem_basem" )
	};

	ttype		= {
		DIB.Create( "status_ttype1" ),
		DIB.Create( "status_ttype2" ),
		DIB.Create( "status_ttype3" ),
		DIB.Create( "status_ttype4" ),
		DIB.Create( "status_ttype5" ),
		DIB.Create( "status_ttype6" ),
		DIB.Create( "status_ttype7" )
	};

	sticon		= {};
	stnotes		= {};

	count_list	= {};
	select_no	= -1;
}

---------------------------------------------------------------------------
--	エンジン起動後、初めてステータス画面が開かれる時に実行される
function status_screen:initialize()
	local buttons	= {
		{ "status_basic_param",		2, 64, 128,   1 },
		{ "status_training_count",	2, 64, 168,   2 },
		{ "status_result",			2, 65, 208,   3 },
		{ "status_achievements",	2, 64, 288,   4 },
		{ "status_back",			2, 65, 697, 125 }
	};

	for k,v in pairs( buttons ) do
		self.modes[k]	= { DIB.Create( v[1], v[2], v[3], v[4] ), DIB.Create( v[1] .. "_hit", 1, v[3], v[4] ), v[5] };
	end

	self.mode_draw_funcs	= {
		[1]	= self.draw_basic,
		[2]	= self.draw_training_count,
		[3]	= self.draw_result,
		[4]	= self.draw_achievements
	};
	self.mode_base	= DIB.Create( self.base_names[1] );

	for i = 1,9 do
		local	x	= math.floor( ( i - 1 ) % 5 ) * 58 + 370;
		local	y	= math.floor( ( i - 1 ) / 5 ) * 46 + 656;
		self.sticon[i]	= DIB.Create( "status_icon"..i, 2, x, y );
		self.stnotes[i]	= DIB.Create( "status_notes"..i, 1, 348, y - 111 );
	end
end

---------------------------------------------------------------------------

function status_screen:build( backstore )
	local	dib	= DIB.Create( "status_base" );
	DIBFill( backstore, 255 * .8, 0, 0, 0 );
	DIBCopy( backstore, 0, 0, dib );

	-- 回数一覧作成
	local	a			= {};
	local	db_name		= "#ID_TC";
	local	db2_name	= "#ID_STC";
	local	ch_name		= { "早紀", "ありさ", "美香子" };
	local	type_name	= { "快楽", "変態", "退廃", "嗜虐", "奉仕", "その他" };

	for k,v in ipairs( ch_name ) do
		local	aa	= {};
		for tk,tv in ipairs( type_name ) do
			local	softs	= {};
			local	notsofts= {};
			for pno,pv in ipairs( var_playlist[k] ) do
				if pv["系統"] == tv then
					if pv["Lv"] == "Soft" then
						table.insert( softs, pno );
					else
						table.insert( notsofts, pno );
					end
				end
			end
			if #notsofts == 0 then
				notsofts	= nil;
			end
			aa[tk]	= { softs, notsofts };
		end
		a[k]	= aa;
	end
--[[
	local	str	= "";
	for k,v in ipairs( a ) do
		str	= str .. "[" .. k .. "]{\n";
		for k2,v2 in ipairs( v ) do
			str	= str .. "\t{\n";
			for k3,v3 in ipairs( v2 ) do
				str	= str .. "\t\t{\n\t\t\t";
				for k4,v4 in ipairs( v3 ) do
					str	= str .. v4 .. ",";
				end
				str	= str .. "\n\t\t}\n";
			end
			str	= str .. "\t}\n";
		end
		str	= str .. "}\n";
	end
	print(str);
--]]
	for k,v in ipairs( ch_name ) do
		local	list	= {};
		local	playlist= var_playlist[k];
		local	aa		= a[k];
		for tk,tv in ipairs( type_name ) do
			local	aaa	= aa[tk];
			list[#list + 1]	= { ["type"] = self.ttype[tk] };
			for bg = 1,2 do
				if aaa[bg] == nil then
					break;
				end

				for bgk,bgv in ipairs( aaa[bg] ) do
					local	item_name	= playlist[bgv]["行為名"];
					if item_name == nil then
						break;
					end
					local	count		= GetDB( db_name, v, playlist[bgv].index );
					if count >= 0 then
						list[#list + 1]	= {
							["type"]	= bg == 1 and self.titem_base.n or self.titem_base.m,
							["name"]	= item_name,
							["count"]	= string.format( "%4d", count )
						};
					end
				end
			end
		end

		list[#list + 1]	= { ["type"] = self.ttype[7] };
		for i = 1,5 do
			local	item_name	= GetDBItemName( db2_name, "y", i - 1 );
			if item_name == nil then
				break;
			end
			local	count		= GetDB( db2_name, v, item_name );
			if count >= 0 then
				list[#list + 1]	= {
					["type"]	= self.titem_base.n,
					["name"]	= item_name,
					["count"]	= string.format( "%4d", count )
				};
			end
		end
		self.count_list[v]	= list;

		--init scroll bar
		self.tc_bar[k]:Init( #list );
	end

	--init scroll bar
	self.res_bar[1]:Init( 21 );
	self.res_bar[2]:Init( 21 );
	self.res_bar[3]:Init( 21 );

	local	no	= 0;
	while true do
		if GetAchievementID( no ) == nil then
			break;
		end
		no	= no + 1;
	end
	if no == 0 then
		no	= 1;
	end
	self.achi_bar:Init( no );
end

---------------------------------------------------------------------------

function status_screen:update( mx, my )
	if self.is_update then
		self.is_update	= false;
		return -2;
	end
	
	self.select_no	= -1;

	for k,v in pairs( self.modes ) do
		if DIBIfHitThenSetState( v[1], v[2], mx, my ) then
			self.select_no	= v[3];
		end
	end

	if self.mode == 1 then
		for k = 0,2 do
			local	offset	= k * 342;
			for i = 0,8 do
				local	x	= math.floor( i % 5 ) * 58 + 370 + offset;
				local	y	= math.floor( i / 5 ) * 46 + 656;
				local	w	= DIBGetWidth( self.sticon[1] );
				local	h	= DIBGetHeight( self.sticon[1] ) / 2;
				if mx > x and my > y and mx < x + w and my < y + h then
					self.select_no	= k * 10 + 10 + i;
					return self.select_no;
				end
			end
		end
	elseif self.mode == 2 then
		local	r1	= self.tc_bar[1]:Update( mx, my );
		local	r2	= self.tc_bar[2]:Update( mx, my );
		local	r3	= self.tc_bar[3]:Update( mx, my );
		if r1 or r2 or r3 then
			self.select_no	= 0x10000;
		end
	elseif self.mode == 3 then
		local	r1	= self.res_bar[1]:Update( mx, my );
		local	r2	= self.res_bar[2]:Update( mx, my );
		local	r3	= self.res_bar[3]:Update( mx, my );
		if r1 or r2 or r3 then
			self.select_no	= 0x10000;
		end
	elseif self.mode == 4 then
		if self.achi_bar:Update( mx, my ) then
			self.select_no	= 0x10000;
		end
	end

	return self.select_no;
end

---------------------------------------------------------------------------

function status_screen:draw( target )
	local	modes	= self.modes;
	local	mode	= self.mode;

	for k,v in pairs( modes ) do
		DIBCopy( target, 0, 0, v[1] );
	end

	if mode >= 1 and mode <= #modes then
		DIBCopy( target, 0, 0, self.mode_base );
		self.mode_draw_funcs[mode]( self, target );
	end
end

---------------------------------------------------------------------------

function status_screen:doaction( select_no )
	if select_no >= 1 and select_no <= 4 then
		self.mode		= select_no;
		self.is_update	= true;
		DIBInit( self.mode_base, self.base_names[select_no] );
	end
end

---------------------------------------------------------------------------

function status_screen:draw_basic( target )
	local	ascfont		= self.ascfont;
	local	ascfont_s	= self.ascfont_s;
	local	db_name		= "#ID_BP";
	local	ch_name		= { "早紀", "ありさ", "美香子" };
	local	param_name	= { "調教進行度", "従順度", "調教受容度", "気力", "BT値", "BT値上昇率", "口感度", "胸感度", "性器感度", "尻感度", "肌感度", "状態" };

	for k,v in ipairs( ch_name ) do
		local	ch_x_offset	= ( k - 1 ) * 342;
		DrawAsciiText( target, 544 + ch_x_offset, 234 + 43 * 0, string.format( "%8d%%", GetDB( db_name, v, param_name[1] ) ), ascfont );
		DrawAsciiText( target, 544 + ch_x_offset, 234 + 43 * 1, string.format( "%9d",   GetDB( db_name, v, param_name[2] ) ), ascfont );
		DrawAsciiText( target, 544 + ch_x_offset, 234 + 43 * 2, string.format( "%9d",   GetDB( db_name, v, param_name[3] ) ), ascfont );
		DrawAsciiText( target, 544 + ch_x_offset, 234 + 43 * 3, string.format( "%9d",   GetDB( db_name, v, param_name[4] ) ), ascfont );
		DrawAsciiText( target, 544 + ch_x_offset, 234 + 43 * 4, string.format( "%3d(%3d%%)", GetDB( db_name, v, param_name[5] ), GetDB( db_name, v, param_name[6] ) ), ascfont );
		for i = 7,11 do
			local	v	= GetDB( db_name, v, param_name[i] );
			local	w	= math.floor( v / 999 * 208 );
			local	x	= 442 + ch_x_offset;
			local	x2	= x + 208 - w;
			local	y	= 485 + 24 * ( i - 7 );
			DIBGradationRect( target, x2, y, w, 17, x + 208, 0, x2, 0, 0xff290a59, 0xffff00ff );
			DrawAsciiText( target, x + 208 - 32 - 26, y - 2, string.format( "%3d", math.floor( v ) ), ascfont );
			DrawAsciiText( target, x + 208 - 26, y + 4, "/999", ascfont_s );
		end
		local	st	= GetDB( db_name, v, param_name[12] );
		for i = 1,8 do
			DIBSetState( self.sticon[i], bit32.band( st, bit32.lshift( 0x1, i - 1 ) ) ~= 0 and 1 or 0 );
			DIBCopy( target, ch_x_offset, 0, self.sticon[i] );
		end
	end
	
	 if self.select_no >= 10 and self.select_no < 40 then
	 	local	ch	= math.floor( ( self.select_no - 10 ) / 10 );
	 	local	no	= math.floor( self.select_no % 10 );
		DIBCopy( target, 342 * ch, 0, self.stnotes[no + 1] );
	 end
end

---------------------------------------------------------------------------

function status_screen:draw_training_count( target )
	local	ascfont		= self.ascfont;
	local	ch_name		= { "早紀", "ありさ", "美香子" };
	local	begin_no	= 1;
	local	end_no		= 18;
	local	x			= 346;
	local	y			= 144 - 24;

	for k,v in ipairs( ch_name ) do
		local	ch_x_offset	= ( k - 1 ) * 342;
		local	first		= self.tc_bar[k].first_line;
		for i = begin_no, end_no do
			local	item	= self.count_list[v][first + i];
			DIBCopy( target, x + ch_x_offset, y + i * 32, item.type );
			DrawText( target, x + 6 + ch_x_offset, y + 8 + i * 32, self.font, translate(item.name) );
			DrawAsciiText( target, x + 266 + ch_x_offset, y + 5 + i * 32, item.count, ascfont );
		end
		self.tc_bar[k]:Draw( target );
	end
end

---------------------------------------------------------------------------

function status_screen:draw_result( target )
	local	ascfont		= self.ascfont;
	local	db_name		= "#ID_LOG";
	local	ch_name		= { "早紀", "ありさ", "美香子" };
	local	begin_no	= 1;
	local	end_no		= 18;
	local	x			= 346;
	local	y			= 144 - 24;

	for k,v in ipairs( ch_name ) do
		local	ch_x_offset	= ( k - 1 ) * 342;
		local	first		= self.res_bar[k].first_line;
		for i = begin_no, end_no do
			local	item_name	= GetDBItemName( db_name, "y", i - 1 + first );
			if item_name == nil then
				break;
			end
			DIBCopy( target, x + ch_x_offset, y + i * 32, self.titem_base.n );
			DrawText( target, x + 6 + ch_x_offset, y + 8 + i * 32, self.font, translate(item_name) );
			DrawAsciiText( target, x + 266 + ch_x_offset, y + 5 + i * 32, string.format( "%4d", GetDB( db_name, v, item_name ) ), ascfont );
		end
		self.res_bar[k]:Draw( target );
	end
end

---------------------------------------------------------------------------

function status_screen:draw_achievements( target )
	local	begin_no	= 0;
	local	end_no		= 17;
	
	for no = begin_no, end_no do
		local	id		= GetAchievementID( self.achi_bar.first_line + no );

		if id == nil then
			break;
		end

		local	info	= GetAchievementInfo( id );
		local	color	= not info.unlock and 0xff404040 or 0;
		if not info.unlock and info.secret then
			info.name	= "？？？";
			info.notes	= "？？？？？";
		end
		DrawText( target, 373,       152 + no * 32, self.font, info.name, color );
		DrawText( target, 373 + 266, 152 + no * 32, self.font, info.notes, color );
	end
	self.achi_bar:Draw( target );
end
