--[[
###############################################################################

                                特別授業SLG
                       簡易キャラ情報ウィンドウ定義

                             ***** 注意 *****
               許可なく本ファイルの内容を変更しないで下さい。
         許可なく変更した結果については全て自己責任でお願いします。

###############################################################################
]]

CHInfoWindow	= {
	ascfont		= DIB.Create( "asciifont" );
	marker		= DIB.Create( "map_marker" );
	icon		= {
		DIB.Create( "status_icon1", 2, 228, 46 * 0 + 14 ),
		DIB.Create( "status_icon2", 2, 228, 46 * 1 + 14 ),
		DIB.Create( "status_icon3", 2, 228, 46 * 2 + 14 ),
		DIB.Create( "status_icon4", 2, 228, 46 * 3 + 14 ),
		DIB.Create( "status_icon5", 2, 228, 46 * 4 + 14 ),
	};
};

function CHInfoWindow:New( base_name, pos, target_name )
	local	wnd	= {};

	wnd.base		= base_name;
	wnd.base_pos	= pos;
	wnd.target_name	= target_name;

	wnd.last_tick	= os.clock();
	wnd.icon_state	= true;

	setmetatable( wnd, { __index = CHInfoWindow } );

	return wnd;
end

---------------------------------------------------------------------------

function CHInfoWindow:initialize()
end

---------------------------------------------------------------------------

function CHInfoWindow:update( target, store )
	local	last	= GetDB( "#ID_BP", self.target_name, "残時間" );
	if last == 1 then
		if os.clock() - self.last_tick > 0.5 then
			self.icon_state	= self.icon_state == false;
			self:draw_icon( target, store );
			self.last_tick	= os.clock();
			return true;
		end
	end
	return false;
end

---------------------------------------------------------------------------

function CHInfoWindow:draw( target, x, y )
	local	tname	= self.target_name;
	local	lv		= GetDB( "#ID_BP", tname, "調教進行度" );
	local	rank	= GetDB( "#ID_BP", tname, "従順度" );
	local	tension	= GetDB( "#ID_BP", tname, "調教受容度" );
	local	status	= GetDB( "#ID_BP", tname, "状態" );
	local	last	= GetDB( "#ID_BP", tname, "残時間" );

	x	= x + self.base_pos[1];
	y	= y + self.base_pos[2];

	DrawAsciiText( target, x + 174, y + 138, string.format( "%3d%%", lv ), self.ascfont );

	local	rx	= math.floor( ( rank + 50 ) / 305 * 181 );
	local	tx	= math.floor( ( tension + 255 ) / 510 * 181 );

	DIBCopy( target, x + 22 + rx, y + 187, self.marker );
	DIBCopy( target, x + 22 + tx, y + 224, self.marker );

	--
	for i = 1,5 do
		local	bit	= bit32.band( status, bit32.lshift( 0x1, i - 1 ) ) ~= 0 and 1 or 0;
		if not ( bit == 1 and last == 1 ) then
			DIBSetState( self.icon[i], bit );
			DIBCopy( target, x, y, self.icon[i] );
		end
	end
end

---------------------------------------------------------------------------

function CHInfoWindow:draw_icon( target, store )
	local	status	= GetDB( "#ID_BP", self.target_name, "状態" );
	local	x		= self.base_pos[1];
	local	y		= self.base_pos[2];
	local	w		= DIBGetWidth( self.icon[1] );
	local	h		= DIBGetHeight( self.icon[1] ) / 2;

	for i = 1,5 do
		local	xx	= x + 228;
		local	yy	= ( i - 1 ) * 46 + y + 14;
		DIBCopy( target, xx, yy, store, { xx, yy, w, h } );
		if self.icon_state and bit32.band( status, bit32.lshift( 0x1, i - 1 ) ) ~= 0 then
			DIBSetState( self.icon[i], 1 );
			DIBCopy( target, x, y, self.icon[i] );
		end
	end
end
