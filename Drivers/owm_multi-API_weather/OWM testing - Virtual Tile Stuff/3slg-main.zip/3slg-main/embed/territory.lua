--[[
###############################################################################

                                特別授業SLG
                         アジトカスタマイズ画面定義

                             ***** 注意 *****
               許可なく本ファイルの内容を変更しないで下さい。
         許可なく変更した結果については全て自己責任でお願いします。

###############################################################################
]]

ter_objs	= ter_objs or OpenCSVDB( "ter_objs" );

--grid準備
function InitGridMap()
	for i = 1,#grid_map do
		for j = 1,#grid_map[i] do
			if grid_map[i][j] then
				grid_map[i][j]	= { no = 0, offset = false, r = false };
			end
		end
	end
end

if grid_map == nil then
	grid_map	= OpenCSVDB( "ter_grid_map" );
	InitGridMap();
end

-------------------------------------------------------------------------------

territory	= territory or {
	base		= DIB.Create( "territory_base" );
	bar			= ScrollBar:New( "ter_bar", 240, 549, 12, 9 );
	bed			= DIB.Create( "ter_bed", 1, 404, 288 );
	exit		= DIB.Create( "ter_exit", 2, -6, -6 );
	removeall	= DIB.Create( "ter_removeall", 2, 929, -5 );
	storage_s	= DIB.Create( "ter_storage_s", 2, 441, 421 );
	storage_l	= DIB.Create( "ter_storage_l", 2, 548, 421 );
	detail_base	= DIB.Create( "ter_detail" );
	storage_base= DIB.Create( "ter_storage_base" );
	storage_head= DIB.Create( "ter_storage_header", 2, 341, 122 );
	storage_close=DIB.Create( "ter_storage_close", 2, 1003, 128 );
	storage_icon= DIB.Create( "ter_storage_icon", 2 );

	grid		= DIB.Create( "ter_grid", 1, 37, 165 );
	grid_w		= 128;
	grid_h		= 64;
	sgrid		= 128;
	
	cursor		= DIB.Create( "ter_cursor" );
	cursor_w	= 138;
	cursor_h	=  74;

	hit_pos		= { 37, 453 };
	pick_pos	= {1200, 683 };
	obj_offset	= {};
	
	font		= DIBText.CreateFont( "ＭＳ　明朝", 14 );
	ascfont		= DIB.Create( "asciifont" );
	
	select_no	= -1;
	pick_no		= 0;

	init		= false;

	total		= {};

	has_objs	= {};
	
	draw_list	= {};
	
	is_update	= false;
	
	open_storage= 0;
};

---------------------------------------------------------------------------
--	square -> quarter
function territory.StoQScreen( sx, sy )
	return ( sx + sy ) / 2, ( sy - sx ) / 4;
end

---------------------------------------------------------------------------
--	quarter -> square
function territory.QtoSScreen( qx, qy )
	return qx - qy * 2, qx + qy * 2;
end

-------------------------------------------------------------------------------

function territory:ParseStatusStr( status )
	local	juujundo	= 0;
	local	juyoudo		= 0;
	local	bit			= 0;

	if status and status[8] then
		local	s	= split( status[8] );
		local	t	= {
			"ぶっ飛び無効",
			"同一行為補正無効",
			"調教時従順度不動",
		};
		local	state_str	= "";

		for k,v in ipairs( s ) do
			local	find	= false;
			for kk,vv in ipairs( t ) do
				if v == vv then
					local	mask	= bit32.lshift( 0x1, kk - 1 );
					if not bit32.btest( bit, mask ) then
						bit	= bit32.bor( bit, mask );
						if #state_str == 0 then
							state_str	= v;
						else
							state_str	= state_str .. "," .. v;
						end
					end
					find	= true;
					break;
				end
			end
			
			if not find then
				if v == "従順度-2" then
					juujundo	= juujundo - 2;
				elseif v == "従順度-1" then
					juujundo	= juujundo - 1;
				elseif v == "従順度+1" then
					juujundo	= juujundo + 1;
				elseif v == "従順度+5" then
					juujundo	= juujundo + 5;
				elseif v == "従順度+10" then
					juujundo	= juujundo + 10;
				elseif v == "調教受容度+2" then
					juyoudo	= juyoudo + 2;
				elseif v == "調教受容度-2" then
					juyoudo	= juyoudo - 2;
				else
					print( "登録されていない補正効果: " .. v );
				end
			end
		end

		if juujundo ~= 0 then
			if #state_str ~= 0 then
				state_str	= state_str .. ",";
			end
			state_str	= state_str .. "従順度";
			if juujundo > 0 then
				state_str	= state_str .. "+" .. juujundo;
			else
				state_str	= state_str .. juujundo;
			end
		end

		if juyoudo ~= 0 then
			if #state_str ~= 0 then
				state_str	= state_str .. ",";
			end
			state_str	= state_str .. "調教受容度";
			if juyoudo > 0 then
				state_str	= state_str .. "+" .. juyoudo;
			else
				state_str	= state_str .. juyoudo;
			end
		end

		status[8]	= state_str;
	end
	
	return juujundo, juyoudo, bit;
end

-------------------------------------------------------------------------------

function territory:GetTotalParam()
	local	total	= { 100, 100, 100, 100, 100, 100, 100, nil };

	for k,v in ipairs( self.draw_list ) do
		local	x	= math.floor( v[2] % 11 );
		local	y	= math.floor( v[2] / 11 );
		local	o	= grid_map[y][x];

		if o and o.no > 0 and o.offset == false then
			local	obj	= ter_objs[o.no];
			for i = 1,7 do
				total[i]	= total[i] + obj.param[i];
			end
			if obj.param[8] then
				if total[8] then
					total[8]	= total[8] .. "," .. obj.param[8];
				else
					total[8]	= obj.param[8];
				end
			end
		end
	end

	for i = 1,7 do
		if total[i] < 0 then
			total[i]	= 0;
		end
	end

	SetDB( "@アジト補正", 0, "口感度",   total[1] );
	SetDB( "@アジト補正", 0, "胸感度",   total[2] );
	SetDB( "@アジト補正", 0, "性器感度", total[3] );
	SetDB( "@アジト補正", 0, "尻感度",   total[4] );
	SetDB( "@アジト補正", 0, "肌感度",   total[5] );
	SetDB( "@アジト補正", 0, "気力",     total[6] );
	SetDB( "@アジト補正", 0, "BT値",     total[7] );

	local	juujundo, juyoudo, bit	= self:ParseStatusStr( total );

	SetDB( "@アジト補正", 0, "従順度", juujundo );
	SetDB( "@アジト補正", 0, "調教受容度", juyoudo );
	SetDB( "@アジト補正", 0, "状態", bit );

	return total;
end

---------------------------------------------------------------------------
--	オブジェの設置
function territory:AddObject( x, y, pick_no )
	local	obj		= self.has_objs[pick_no];
	local	size	= ter_objs[obj.no].size;
	local	reverse	= x >= 9;
	local	check	= false;
	local	grid	= grid_map;

	if size == "L" then
		if reverse then
			if grid[y - 1][x] == false then y = y + 1; end
		else
			if grid[y][x + 1] == false then x = x - 1; end
		end
	elseif size == "LL" then
		if grid[y - 1][x] == false then y = y + 1; end
		if grid[y][x + 1] == false then x = x - 1; end
		if grid[y - 1][x] == false then y = y + 1; end
	end

	if grid[y][x] then
		if size == "L" then
			if reverse then
				if grid[y - 1][x] then
					check	= true;
				end
			else
				if grid[y][x + 1] then
					check	= true;
				end
			end
		elseif size == "LL" then
			if grid[y][x + 1] and grid[y - 1][x] and grid[y - 1][x + 1] then
				check	= true;
			end
		else
			check	= true;
		end
	end

	if check then
		self:RemoveObject( x, y );
		if size == "L" then
			if reverse then
				self:RemoveObject( x, y - 1 );
			else
				self:RemoveObject( x + 1, y );
			end
		elseif size == "LL" then
			self:RemoveObject( x + 1, y );
			self:RemoveObject( x, y - 1 );
			self:RemoveObject( x + 1, y - 1 );
		end

		if size == "L" then
			if reverse then
				grid[y - 1][x]	= { no = obj.no, offset = { x = 0, y = 1 }, r = false };
			else
				grid[y][x + 1]	= { no = obj.no, offset = { x = -1, y = 0 }, r = false };
			end
		elseif size == "LL" then
			grid[y][x + 1]		= { no = obj.no, offset = { x = -1, y = 0 }, r = false };
			grid[y - 1][x]		= { no = obj.no, offset = { x = 0, y = 1 }, r = false };
			grid[y - 1][x + 1]	= { no = obj.no, offset = { x = -1, y = 1 }, r = false };
		end
		grid[y][x]	= { no = obj.no, offset = false, r = reverse, pick = pick_no };
		obj.num		= obj.num - 1;
		CommonData["ter_grid"][y * 11 + x]	= obj.no;

		local	dx	= 10 - x;
		local	dy	= y - 2;
		if size == "L" then
			if reverse then
				dy	= dy - 0.5;
			else
				dx	= dx - 0.5;
			end
		elseif size == "LL" then
			dx	= dx - 0.5;
			dy	= dy - 0.5;
		end

		--[1]簡易比較用(大きい方が手前に表示)[2]設置基準座標
--local str = "";
		local	nv	= { dx + dy, y * 11 + x };
--str = str .. "nv[" .. nv[1] .. "]: " .. x .. "/" .. y .. "\n";
		for k,v in ipairs( self.draw_list ) do
--str = str .. "v[" .. v[1] .. "]: " .. math.floor( v[2] % 11 ) .. "/" .. math.floor( v[2] / 11 ) .. "\n";
			if v[1] > nv[1] then
--str = str .. "v[1] > nv[1]" .. "\n";
				table.insert( self.draw_list, k, nv );
				return;
			elseif v[1] == nv[1] then
--str = str .. "v[1] == nv[1]" .. "\n";
				--v[1]の大小では判断できない場合、具体的な座標で判断する
				local	d	= nv[1];
				local	pos	= #self.draw_list + 1;
--str = str .. "k: " .. k .. ", #: " .. #self.draw_list .. "\n";
				for i = k,#self.draw_list do
					v	= self.draw_list[i];
					if d < v[1] then
--str = str .. "not found" .. "\n";
						pos	= i;
						break;
					end

					local	vx	= math.floor( v[2] % 11 );
					local	vy	= math.floor( v[2] / 11 );
					local	priority	= false;
					if x >= 9 and vx >= 9 then
						--x判定優先
						if x > vx then
--str = str .. "x >= 9 and vx >= 9: x > vx" .. "\n";
							pos	= i;
							break;
						elseif x == vx and y < vy then
--str = str .. "x >= 9 and vx >= 9: x == vx and y < vy" .. "\n";
							pos	= i;
							break;
						end
					else
						--y判定優先
						if y < vy then
--str = str .. "y < vy" .. "\n";
							pos	= i;
							break;
						elseif y == vy and x > vx then
--str = str .. "y == vy and x > vx" .. "\n";
							pos	= i;
							break;
						end
					end
				end
--print( str .. "pos: " .. pos )
				table.insert( self.draw_list, pos, nv );
				return;
			end
		end

--print( str .. "pos: *last*" )
		table.insert( self.draw_list, nv );
	end
end

---------------------------------------------------------------------------
--	オブジェの撤去
function territory:RemoveObject( x, y )
	local	obj		= grid_map[y][x];

	if obj == false or obj.no <= 0 then
		return 0;
	end

	if obj.offset then
		x	= x + obj.offset.x;
		y	= y + obj.offset.y;
	end
	
	local	size	= ter_objs[obj.no].size;
	local	reverse	= grid_map[y][x].r;
	local	initobj	= { no = 0, offset = false, r = false };
	local	pick_no	= grid_map[y][x].pick;

	if pick_no > 0 then
		local	o	= self.has_objs[pick_no];
		o.num	= o.num + 1;
	end
	grid_map[y][x]	= initobj;
	if size == "L" then
		if reverse then
			grid_map[y - 1][x]	= initobj;
		else
			grid_map[y][x + 1]	= initobj;
		end
	elseif size == "LL" then
		grid_map[y + 0][x + 1]	= initobj;
		grid_map[y - 1][x + 0]	= initobj;
		grid_map[y - 1][x + 1]	= initobj;
	end
	CommonData["ter_grid"][y * 11 + x]	= nil;

	for k,v in ipairs( self.draw_list ) do
		if v[2] == y * 11 + x then
			table.remove( self.draw_list, k );
			break;
		end
	end
	
	return pick_no;
end

---------------------------------------------------------------------------
--	全オブジェの撤去
function territory:RemoveAllObject()
	for i = 1,#grid_map do
		for j = 1,#grid_map[i] do
			if grid_map[i][j] then
				local	grid	= grid_map[i][j];
				if grid.no > 0 and not grid.offset then
					if grid.pick > 0 then
						local	o	= self.has_objs[grid.pick];
						o.num	= o.num + 1;
					end
				end
				grid_map[i][j]	= { no = 0, offset = false, r = false };
			end
		end
	end
	CommonData["ter_grid"]	= {};
	self.draw_list			= {};
end

---------------------------------------------------------------------------

function territory:RelocationObjects( store_data )
	for k,v in pairs( store_data ) do
		local	x, y	= math.floor( k % 11 ), math.floor( k / 11 );
		for kk,vv in pairs( self.has_objs ) do
			if vv.no == v then
				self:AddObject( x, y, kk );
				break;
			end
		end
	end
end

---------------------------------------------------------------------------

function territory:ShowStorageData( target, x, y, data, is_hit )
	local	total	= { 100, 100, 100, 100, 100, 100, 100, nil };
	local	color	= is_hit and 0 or 0xff808080;
	
	if not data or type(data) ~= "table" then
		return;
	end
	
	local	empty	= true;
	for k,v in pairs( data ) do
		empty	= false;
		break;
	end
	
	if empty then
		DrawAsciiText( target, x, y, "empty", self.ascfont, color );
		return;
	end

	for k,v in pairs( data ) do
		local	objs	= ter_objs[v];
		for i = 1,7 do
			total[i]	= total[i] + objs.param[i];
		end
		if objs.param[8] then
			if total[8] then
				total[8]	= total[8] .. "," .. objs.param[8];
			else
				total[8]	= objs.param[8];
			end
		end
	end

	for i = 1,7 do
		if total[i] < 0 then
			total[i]	= 0;
		end
	end

	self:ParseStatusStr( total );

	DIBSetState( self.storage_icon, is_hit and 1 or 0 );
	DIBCopy( target, x, y, self.storage_icon );
	for i = 1, 7 do
		DrawText( target, x + 26 + 80 * ( i - 1 ), y, self.font, translate(total[i]) .. "%", color );
	end
	if total[8] then
		DrawText( target, x, y + 21, self.font, translate(total[8]), color );
	end
end

---------------------------------------------------------------------------

function territory:StorePlacement( no )
	if no < 1 or no > 10 then
		return;
	end

	local	src		= CommonData["ter_grid"];
	local	dest	= {};
	for k,v in pairs( src ) do
		dest[k]	= v;
	end
	CommonData["ter_grid_storage"][no]	= dest;
end

---------------------------------------------------------------------------

function territory:RestorePlacement( no )
	if no < 1 or no > 10 then
		return;
	end

	self:RemoveAllObject();
	self:RelocationObjects( CommonData["ter_grid_storage"][no] );
	self.total		= self:GetTotalParam();
	self.pick_no	= 0;
end

---------------------------------------------------------------------------

function territory:initialize( target )
	--初回のみ実行
	if self.init == false then
		local	_pos	= {
			["S"]	= { -self.grid_w * 0.5, -self.grid_h * 1.5 },
			["M"]	= { -self.grid_w * 0.5, -self.grid_h * 2.5 },
			["L"]	= { -self.grid_w * 1.0, -self.grid_h * 3.5 },
			["LL"]	= { -self.grid_w * 1.0, -self.grid_h * 3.5 },
		};
		for k,v in pairs( _pos ) do
			self.obj_offset[k]	= v;
		end

		for k,v in pairs( ter_objs ) do
			v.img	= DIB.Create( v.filename );
		end

		CommonData["ter_grid"]	= CommonData["ter_grid"] or { [2*11+6]=50, [2*11+10]=42, [4*11+10]=52, [6*11+10]=51 };

		--設置状態の保存
		if not CommonData["ter_grid_storage"] then
			CommonData["ter_grid_storage"]	= {};
			for i = 1, 10 do
				CommonData["ter_grid_storage"][i]	= {};
			end
		end

		self.init	= true;
	end

	SetSysButtonShortcut( false );

	--毎回実行
	self.has_objs	= {};
	for k,v in ipairs( ter_objs ) do
		local	data	= GetDB( "@オブジェ", 0, v.name );
		if data > 0 then
			table.insert( self.has_objs, { no = k, name = v.name, num = data } );
		end
	end

	InitGridMap();
	self.draw_list	= {};
	self:RelocationObjects( CommonData["ter_grid"] );
	self.total		= self:GetTotalParam();

	self.pick_no	= 0;

	self.bar:Init( #self.has_objs );

	DIBSetState( self.exit, 0 );
	DIBSetState( self.removeall, 0 );
	DIBSetState( self.storage_s, 0 );
	DIBSetState( self.storage_l, 0 );
	DIBSetState( self.storage_head, 0 );
	DIBSetState( self.storage_close, 0 );
	DIBSetState( self.storage_icon, 0 );

	self:draw( target );
	
	return true;
end

---------------------------------------------------------------------------

function territory:update( mx, my )
	local	forced_refresh	= false;

	if self.is_update then
		self.is_update	= false;
		return -2, false;
	end

	self.select_no	= -1;

	--設置状態の保存
	if self.open_storage > 0 then
		for i = 1, 10 do
			local	x	= 394;
			local	y	= 160 + 48 * ( i - 1 );
			if mx >= x and mx < x + 576 and my >= y and my < y + 42 then
				self.select_no	= 512 + i;
				break;
			end
		end

		DIBSetState( self.storage_close, 0 );
		if mx >= 1003 and mx < 1003+16 and my >= 128 and my < 128+16 then
			DIBSetState( self.storage_close, 1 );
			self.select_no	= 768;
		end

		return self.select_no, forced_refresh;
	end

	--grid内
	local	sx, sy	= self.QtoSScreen( mx - self.hit_pos[1], my - self.hit_pos[2] );
	local	cx, cy	= sx - sx % self.sgrid + self.sgrid / 2, sy - sy % self.sgrid + self.sgrid / 2;
	local	bx, by	= math.floor( cx / self.sgrid ), math.floor( cy / self.sgrid );

	if bx >= 0 and bx <= 8 and by >= 0 and by <= 6 then
		local	obj	= grid_map[by + 2][bx + 2];
		if obj then
			self.select_no	= by * 11 + bx;
		end
	end

	--所持オブジェ
	for i = 0, 8 do
		local	first_line	= i + self.bar.first_line;

		if first_line < 0 or first_line >= #self.has_objs then
			break;
		end

		local	w	= 192;
		local	h	= 21;
		local	x	= 48;
		local	y	= 549 + h * i;
		local	obj	= self.has_objs[first_line + 1];

		if obj.num > 0 and mx >= x and my >= y and mx < x + w and my < y + h then
			self.select_no	= 128 + i;
			break
		end
	end

	--スクロールバー
	if self.bar:Update( mx, my ) then
		forced_refresh	= true;
	end

	--カスタマイズ画面を抜ける
	DIBSetState( self.exit, 0 );
	if mx >= 5 and mx < 90 and my >= 5 and my < 74 then
		DIBSetState( self.exit, 1 );
		self.select_no	= 125;
	end

	--全オブジェ撤去
	DIBSetState( self.removeall, 0 );
	if mx >= 929 and mx < 929+140 and my >= 5 and my < 74 then
		DIBSetState( self.removeall, 1 );
		self.select_no	= 256;
	end

	--倉庫を開く
	DIBSetState( self.storage_s, 0 );
	if mx >= 441 and mx < 441+106 and my >= 421 and my < 421+85 then
		DIBSetState( self.storage_s, 1 );
		self.select_no	= 257;
	end

	DIBSetState( self.storage_l, 0 );
	if mx >= 548 and mx < 548+106 and my >= 421 and my < 421+85 then
		DIBSetState( self.storage_l, 1 );
		self.select_no	= 258;
	end

	return self.select_no, forced_refresh;
end

---------------------------------------------------------------------------

function territory:DrawTextManually(target, x, y, font, text, color, scale)
    if not text:find(" ") then
        DrawText(target, x, y, font, text, color, scale)
        return
    end

    local estimated_char_width = 10
    local space_width = 5

    -- Apply the scaling factor from the original call
    local final_scale = scale or 1.0
    local scaled_char_width = estimated_char_width * final_scale
    local scaled_space_width = space_width * final_scale

    -- Split the text into a table of words
    local words = {}
    for word in text:gmatch("([^ ]+)") do
        table.insert(words, word)
    end

    local current_x = x
    for i, word in ipairs(words) do
        -- Draw the current word at the current position
        DrawText(target, current_x, y, font, word, color, scale)

        -- Calculate the estimated width of the word we just drew
        local estimated_word_width = #word * scaled_char_width

        -- Update the x position for the next word
        current_x = current_x + estimated_word_width

        -- Add the space width, but not after the very last word
        if i < #words then
            current_x = current_x + scaled_space_width
        end
    end
end

function territory:draw( target )
	--基本
	DIBCopy( target, 0, 0, self.base );
	if self.select_no >= 0 and self.select_no < 11 * 9 then
		local	select_no	= self.select_no;
		local	bx, by		= math.floor( select_no % 11 ), math.floor( select_no / 11 );
		local	qx, qy		= self.StoQScreen( self.sgrid * bx + self.sgrid / 2, self.sgrid * by + self.sgrid / 2 );
		qx	= qx + self.hit_pos[1];
		qy	= qy + self.hit_pos[2];
		DIBCopy( target, 0, 0, self.grid );
		DIBCopy( target, qx - self.cursor_w / 2, qy - self.cursor_h / 2, self.cursor );
	end

	--オブジェの配置
	for k,v in ipairs( self.draw_list ) do
		local	tx			= math.floor( v[2] % 11 ) - 2;
		local	ty			= math.floor( v[2] / 11 ) - 2;
		local	obj_ongrid	= grid_map[ty + 2][tx + 2];
		if obj_ongrid and obj_ongrid.no > 0 and obj_ongrid.offset == false then
			local	obj		= ter_objs[obj_ongrid.no];
			local	offset	= self.obj_offset[obj.size];
			local	qx, qy	= self.StoQScreen( self.sgrid * tx + self.sgrid / 2, self.sgrid * ty + self.sgrid / 2 );
			qx	= qx + self.hit_pos[1] + offset[1];
			qy	= qy + self.hit_pos[2] + offset[2];
			DIBCopy( target, qx, qy, obj.img, nil, obj_ongrid.r );
		end
	end

	DIBCopy( target, 0, 0, self.bed );

	local	i;

	--調教時の補正効果
	local	total	= self.total;
	for i = 1,7 do
		local	x	= math.floor( ( i - 1 ) % 2 ) * 112 + 1152;
		local	y	= math.floor( ( i - 1 ) / 2 ) *  42 +   58;
		DrawAsciiText( target, x, y, string.format( "%5d%%", total[i] ), self.ascfont );
	end
	--その他
	i	= 0;
	if total[8] then
		local	tokens	= split( total[8] );
		for k,v in pairs( tokens ) do
			DrawText( target, 1110, 231 + math.floor(21.5 * i), self.font, translate(v) );
			i	= i + 1;
		end
	end

	--ピックアップ中のオブジェクト
	if self.pick_no > 0 then
		local	obj	= ter_objs[self.has_objs[self.pick_no].no];
		local	px	= self.pick_pos[1] + self.obj_offset[obj.size][1];
		local	py	= self.pick_pos[2] + self.obj_offset[obj.size][2];
		DIBCopy( target, px, py, obj.img );
		self:DrawTextManually( target, 280, 570, self.font, translate(obj.name), 0, 1.5 );

		for i = 1,7 do
			local	v	= obj.param[i];
			if v ~= 0 then
				local	x	= math.floor( ( i - 1 ) % 4 ) * 117 + 330;
				local	y	= math.floor( ( i - 1 ) / 4 ) *  58 + 640;
				DrawAsciiText( target, x, y, string.format( "%+4d%%", v ), self.ascfont );
			end
		end
		--その他
		i	= 0;
		if obj.param[8] then
			local	tokens	= split( obj.param[8] );
			for k,v in pairs( tokens ) do
				DrawText( target, 774, 615 + math.floor(21.5 * i), self.font, translate(v) );
				i	= i + 1;
			end
		end
	end

	--所持オブジェ一覧
	for i = 0, 8 do
		local	obj	= self.has_objs[self.bar.first_line + i + 1];
		if obj == nil then
			break;
		end
		local	color	= obj.num == 0 and 0xff808080 or 0;
		DrawText( target, 42, 552 + 22 * i, self.font, translate(obj.name)..":"..obj.num, color );
	end
	if self.select_no >= 128 and self.select_no <= 128 + 8 then
		i	= self.select_no - 128;
		DIBReverseColor( target, 42, 549 + 22 * i, 192, 22 );
	end

	--設置状態の保存
	if self.open_storage > 0 then
		DIBCopy( target, 0, 0, self.storage_base );
		DIBCopy( target, 0, 0, self.storage_head );
		DIBCopy( target, 0, 0, self.storage_close );
		for k,v in ipairs( CommonData["ter_grid_storage"] ) do
			self:ShowStorageData( target, 389, 157 + 48 * ( k - 1 ), v, k == self.select_no - 512 );
		end
		return;
	end

	self.bar:Draw( target );

	DIBCopy( target, 0, 0, self.exit );
	DIBCopy( target, 0, 0, self.removeall );
	DIBCopy( target, 0, 0, self.storage_s );
	DIBCopy( target, 0, 0, self.storage_l );
	
	-- show status object on cursor
	if self.select_no >= 0 and self.select_no < 11 * 9 then
		local	select_no	= self.select_no;
		local	bx, by		= math.floor( select_no % 11 ), math.floor( select_no / 11 );
		local	grid		= grid_map[by + 2][bx + 2];
		if grid and grid.no > 0 then
			local	qx, qy	= self.StoQScreen( self.sgrid * bx + self.sgrid / 2, self.sgrid * by + self.sgrid / 2 );
			local	objs	= ter_objs[grid.no];
			qx	= qx + self.hit_pos[1] - 85;
			qy	= qy + self.hit_pos[2] + math.floor( self.grid_h / 2 );
			DIBCopy( target, qx - 12, qy - 12, self.detail_base );
			DrawText( target, qx, qy, self.font, translate(objs.name) );
			for i=0,6 do
				if objs.param[i + 1] ~= 0 then
					DrawAsciiText( target, qx + 37 + 80 * math.floor( i % 2 ), qy + 21 + 21 * math.floor( i / 2 ), string.format( "%+3d%%", objs.param[i + 1] ), self.ascfont );
				end
			end
			DrawText( target, qx, qy + 112, self.font, translate(objs.param[8]) );
		end
	end
end

---------------------------------------------------------------------------

function territory:doaction( key )
	if key == KEY_A then
		local	select_no	= self.select_no;

		--カスタマイズ画面を抜ける
		if select_no == 125 then
			return true;
		end

		--倉庫が開いてたら閉じる
		if self.open_storage > 0 then
			if select_no <= 512 + 10 then
				if self.open_storage == 1 then
					self:StorePlacement( select_no - 512 );
				else
					self:RestorePlacement( select_no - 512 );
				end
			end
			self.open_storage	= 0;
			self.is_update		= true;
			return false;
		end

		--全オブジェ撤去
		if select_no == 256 then
			self:RemoveAllObject();
			self.total		= self:GetTotalParam();
			self.is_update	= true;
			return false;
		end

		--倉庫を開く
		if select_no == 257 then
			DIBSetState( self.storage_head, 0 );
			self.open_storage	= 1;
			self.is_update		= true;
			return false;
		elseif select_no == 258 then
			DIBSetState( self.storage_head, 1 );
			self.open_storage	= 2;
			self.is_update		= true;
			return false;
		end

		--所持オブジェ欄
		if select_no >= 128 and select_no <= 128 + 8 then
			local	no	= ( select_no - 127 ) + self.bar.first_line;
			self.pick_no	= no;
			self.is_update	= true;
			return false;
		end

		--配置
		if self.pick_no > 0 then
			self:AddObject( math.floor( select_no % 11 ) + 2, math.floor( select_no / 11 ) + 2, self.pick_no );
			self.total		= self:GetTotalParam();
			self.pick_no	= 0;
			self.is_update	= true;
		elseif select_no >= 0 and select_no < 11 * 9 then
			self.pick_no	= self:RemoveObject( math.floor( select_no % 11 ) + 2, math.floor( select_no / 11 ) + 2 );
			self.total		= self:GetTotalParam();
			self.is_update	= true;
		end
	elseif key == KEY_B then
		--倉庫が開いてたら閉じる
		if self.open_storage > 0 then
			self.open_storage	= 0;
			self.is_update		= true;
		else
			local	select_no	= self.select_no;
			if select_no >= 0 and select_no < 11 * 9 then
				self:RemoveObject( math.floor( select_no % 11 ) + 2, math.floor( select_no / 11 ) + 2 );
				self.total		= self:GetTotalParam();
				self.is_update	= true;
			end
		end
	elseif key == KEY_WU then
		self.is_update	= self.bar:ScrollUp();
		return true;
	elseif key == KEY_WD then
		self.is_update	= self.bar:ScrollDown();
		return true;
	end

	return false;
end

---------------------------------------------------------------------------

function territory:rebuild( target, state )
	self:draw( target );
end

---------------------------------------------------------------------------
function IsDisableBT( result )
	if result then
		SetScenarioValue( result, bit32.btest( GetDB( "@アジト補正", 0, "状態" ), bit32.lshift( 0x1, 0 ) ) and 1 or 0 );
	end
end

---------------------------------------------------------------------------
function FlagON( target, name )
	for k,v in ipairs( { "バイブ", "ローター", "アナルパール", "下着脱衣", "薬", "気絶", "まぐろ", "フィーバー" } ) do
		if name == v then
			local	state	= GetDB( "#ID_BP", target, "状態" );
			bit32.bor( state, bit32.lshift( 0x1, k - 1 ) );
			SetDB( "#ID_BP", target, "状態", state );
		end
	end
end

---------------------------------------------------------------------------
function FlagOFF( target, name )
	for k,v in ipairs( { "バイブ", "ローター", "アナルパール", "下着脱衣", "薬", "気絶", "まぐろ", "フィーバー" } ) do
		if name == v then
			local	state	= GetDB( "#ID_BP", target, "状態" );
			bit32.band( state, bit32.bnot( bit32.lshift( 0x1, k - 1 ) ) );
			SetDB( "#ID_BP", target, "状態", state );
		end
	end
end

---------------------------------------------------------------------------
function FlagCheck( target, name, result )
	if result then
		for k,v in ipairs( { "バイブ", "ローター", "アナルパール", "下着脱衣", "薬", "気絶", "まぐろ", "フィーバー" } ) do
			if name == v then
				SetScenarioValue( result, bit32.btest( GetDB( "#ID_BP", target, "状態" ), bit32.lshift( 0x1, k - 1 ) ) and 1 or 0 );
			end
		end
	end
end

---------------------------------------------------------------------------
function GetObjectTest( result )
	local	r		= math.random( 256 );
	local	items	= {};
	
	--沙耶人形
	if r == 1 then
		for k,v in ipairs( ter_objs ) do
			if v.name == "等身大フィギュア" then
				if GetDB( "@ID_HASOBJS", 0, v.name ) < 9 then
					table.insert( items, v.refer_no );
				end
				break;
			end
		end
	end

	--size:LL
	if #items == 0 and r < 12 then
		for k,v in ipairs( ter_objs ) do
			if v.size == "LL" then
				if GetDB( "@ID_HASOBJS", 0, v.name ) < 9 then
					table.insert( items, v.refer_no );
				end
			end
		end
	end

	--size:L
	if #items == 0 and r < 32 then
		for k,v in ipairs( ter_objs ) do
			if v.size == "L" then
				if GetDB( "@ID_HASOBJS", 0, v.name ) < 9 then
					table.insert( items, v.refer_no );
				end
			end
		end
	end

	--size:M
	if #items == 0 and r < 64 then
		for k,v in ipairs( ter_objs ) do
			if v.size == "M" and v.name ~= "等身大フィギュア" then
				if GetDB( "@ID_HASOBJS", 0, v.name ) < 9 then
					table.insert( items, v.refer_no );
				end
			end
		end
	end

	--size:S
	if #items == 0 then
		for k,v in ipairs( ter_objs ) do
			if v.size == "S" then
--				if GetDB( "@ID_HASOBJS", 0, v.name ) < 9 then
					table.insert( items, v.refer_no );
--				end
			end
		end
	end

	SetScenarioValue( result, #items == 0 and -1 or items[math.random( #items )] );
end

--[[
function GetObjectTestTest()
	local	ary	= {};
	local	v;
	for i = 0,10000 do
		GetObjectTest( "#item" );
		v	= GetScenarioValue( "#item" ) + 2;
		if ary[v] then
			ary[v] = ary[v] + 1;
		else
			ary[v] = 1;
		end
	end
	local	str	= "";
	for k,v in pairs( ary ) do
		for kk,vv in ipairs( ter_objs ) do
			if vv.refer_no == k-2 then
					str = str .. vv.size .. "\t" .. vv.name .. "\t";
				break;
			end
		end
		str = str .. k .. "\t" .. v .. "\n";
	end
	print(str);
end
--]]
