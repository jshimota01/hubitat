@echo off
REM This batch file executes the PowerShell script, bypassing execution policy for this one-time run.
REM It does not permanently change any system settings.

TITLE GitGud Automatic Patcher

REM Find the PowerShell script in the same directory as this batch file.
SET "SCRIPT_PATH=%~dp0patcher.ps1"

REM Execute PowerShell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT_PATH%"

REM Pause to keep the window open so the user can see the results.
echo.
pause