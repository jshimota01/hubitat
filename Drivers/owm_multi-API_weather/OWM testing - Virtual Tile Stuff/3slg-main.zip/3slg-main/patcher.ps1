#  ----- AUTOMATIC TL PATCHER (PowerShell Edition) v4.0 -----
#
#  Instructions:
#  1. Make sure the target repository is PUBLIC on GitGud.
#  2. Set the $RepoURL variable below.
#  3. Place this script and "run-patcher.bat" in the folder you want to patch.
#  4. Double-click "run-patcher.bat" to start.
#
#  v4.0: Checks the latest commit hash to avoid downloading if already up-to-date.

# ----- CONFIGURATION -----
$RepoURL = "https://gitgud.io/SakuraKoi/3SLG" # <-- CHANGE THIS URL
$LocalVersionFile = ".patcher_version"                  # Stores the last installed commit hash
# -------------------------


# ----- SCRIPT (No need to edit below this line) -----

Function Show-Confirmation {
    Write-Host "============================================================" -ForegroundColor Yellow
    Write-Host "           AUTOMATIC TL PATCHER" -ForegroundColor Yellow
    Write-Host "============================================================" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "This script will check for updates from:" -ForegroundColor Magenta
    Write-Host "  > $RepoURL"
    Write-Host ""
    Write-Host "Please ensure that the files are in the game root dir."
    Write-Host "The files will be placed and replaced there."
    Write-Host ""
    Write-Host "IMPORTANT: Do not run any .bat or Powershell scripts you don't trust." -ForegroundColor Red
    Write-Host "You should be able to always look inside them." -ForegroundColor Red
    Write-Host "------------------------------------------------------------"
    try {
        Read-Host "Press [Enter] to check for updates, or close this window to cancel."
        Write-Host "------------------------------------------------------------"
        return $true
    } catch {
        Write-Host "`n`nProcess cancelled by user." -ForegroundColor Red
        return $false
    }
}

Function Get-RemoteRepositoryInfo {
    param([string]$URL)

    $RepoUri = [System.Uri]$URL
    $ProjectPath = $RepoUri.AbsolutePath.Trim('/')
    if ([string]::IsNullOrWhiteSpace($ProjectPath)) {
        throw "Repo URL '$URL' is missing a project path."
    }

    $EncodedProjectPath = [System.Uri]::EscapeDataString($ProjectPath)
    $ApiBase = "{0}://{1}/api/v4/projects/{2}" -f $RepoUri.Scheme, $RepoUri.Authority, $EncodedProjectPath
    $ProjectInfo = Invoke-RestMethod -Uri $ApiBase -Method Get -ErrorAction Stop

    return [PSCustomObject]@{
        ApiBase       = $ApiBase
        DefaultBranch = $ProjectInfo.default_branch
        ProjectName   = ($ProjectPath -split '/')[-1]
    }
}

Function Get-RemoteCommitHash {
    param([string]$URL)

    Write-Host "-> Checking for updates online..." -ForegroundColor Cyan
    try {
        $RemoteInfo = Get-RemoteRepositoryInfo -URL $URL
        $CommitsURL = "$($RemoteInfo.ApiBase)/repository/commits?per_page=1"
        if (-not [string]::IsNullOrWhiteSpace($RemoteInfo.DefaultBranch)) {
            $CommitsURL += "&ref_name=$([System.Uri]::EscapeDataString($RemoteInfo.DefaultBranch))"
        }

        $Commits = Invoke-RestMethod -Uri $CommitsURL -Method Get -ErrorAction Stop
        if ($Commits -and $Commits[0].id) {
            $RemoteHash = $Commits[0].id
            if (-not [string]::IsNullOrWhiteSpace($RemoteInfo.DefaultBranch)) {
                Write-Host "   Default branch is:        $($RemoteInfo.DefaultBranch)"
            }
            Write-Host "   Latest online version is: $($RemoteHash.Substring(0,8))"
            return [PSCustomObject]@{
                CommitHash    = $RemoteHash
                ApiBase       = $RemoteInfo.ApiBase
                DefaultBranch = $RemoteInfo.DefaultBranch
                ProjectName   = $RemoteInfo.ProjectName
            }
        }
    } catch {
        Write-Host "   Could not determine online version. Will proceed with download." -ForegroundColor Yellow
    }

    Write-Host "   Could not determine online version. Will proceed with download." -ForegroundColor Yellow
    return $null
}

Function Sync-FilesWithHashCheck {
    param([string]$SourceDirectory, [string]$DestinationDirectory, [array]$FilesToSkip)
    Get-ChildItem -Path $SourceDirectory -Recurse | ForEach-Object {
        $SourceItem = $_
        $RelativePath = $SourceItem.FullName.Substring($SourceDirectory.Length + 1)
        $DestinationItemPath = Join-Path $DestinationDirectory $RelativePath

        if ($SourceItem.PSIsContainer) {
            if (-not (Test-Path $DestinationItemPath)) { New-Item -Path $DestinationItemPath -ItemType Directory -Force | Out-Null }
        } else {
            if ($SourceItem.Name -in $FilesToSkip) { return }
            $ParentDir = Split-Path -Path $DestinationItemPath -Parent
            if (-not (Test-Path $ParentDir)) { New-Item -Path $ParentDir -ItemType Directory -Force | Out-Null }

            if (-not (Test-Path $DestinationItemPath) -or ((Get-FileHash $SourceItem.FullName).Hash -ne (Get-FileHash $DestinationItemPath).Hash)) {
                Write-Host "      -> Updating '$RelativePath'..."
                Copy-Item -Path $SourceItem.FullName -Destination $DestinationItemPath -Force
            }
        }
    }
}

Function Start-Patch {
    # --- Step 1: Check for updates before doing anything else ---
    $RemoteState = Get-RemoteCommitHash -URL $RepoURL
    $RemoteCommitHash = if ($RemoteState) { $RemoteState.CommitHash } else { $null }
    
    if (Test-Path $LocalVersionFile) {
        $LocalCommitHash = Get-Content $LocalVersionFile
        Write-Host "   Your current version is:    $($LocalCommitHash.Substring(0,8))"
    } else {
        $LocalCommitHash = ""
        Write-Host "   No local version found. A clean installation will be performed."
    }

    if ($RemoteCommitHash -and ($RemoteCommitHash -eq $LocalCommitHash)) {
        Write-Host "`nYou are already up-to-date! No action needed." -ForegroundColor Green
        return # Exit the function
    }
    Write-Host "`nAn update is available or this is a first run. Proceeding..." -ForegroundColor Green
    
    # --- If we get here, an update is needed ---
    if ($RemoteState) {
        $ApiBase = $RemoteState.ApiBase
        $ProjectName = $RemoteState.ProjectName
        $DefaultBranch = $RemoteState.DefaultBranch
    } else {
        $RemoteInfo = Get-RemoteRepositoryInfo -URL $RepoURL
        $ApiBase = $RemoteInfo.ApiBase
        $ProjectName = $RemoteInfo.ProjectName
        $DefaultBranch = $RemoteInfo.DefaultBranch
    }

    $TempDir = Join-Path $env:TEMP ([System.Guid]::NewGuid().ToString())
    $DownloadSuccessful = $false

    try {
        New-Item -ItemType Directory -Path $TempDir -Force | Out-Null

        # --- Step 2: Download ---
        Write-Host "`n[1/3] Downloading repository..." -ForegroundColor Yellow
        $BranchesToTry = @()
        if (-not [string]::IsNullOrWhiteSpace($DefaultBranch)) {
            $BranchesToTry += $DefaultBranch
        }
        $BranchesToTry += "main", "master"
        $BranchesToTry = $BranchesToTry | Select-Object -Unique

        foreach ($branch in $BranchesToTry) {
            if ($branch -eq $DefaultBranch) {
                $ZipURL = "$ApiBase/repository/archive.zip"
            } else {
                $ZipURL = "$ApiBase/repository/archive.zip?sha=$([System.Uri]::EscapeDataString($branch))"
            }

            $ZipPath = Join-Path $TempDir "repo.zip"
            try {
                $ProgressPreference = 'SilentlyContinue'
                Invoke-WebRequest -Uri $ZipURL -OutFile $ZipPath -UseBasicParsing -ErrorAction Stop
                $DownloadSuccessful = $true
                Write-Host "      Downloaded archive for '$branch'."
                break
            } catch { }
        }
        if (-not $DownloadSuccessful) { throw "Could not download from the GitGud API archive endpoint. Check URL and that repo is public." }
        Write-Host "      Download complete."

        # --- Step 3: Extract & Sync ---
        Write-Host "`n[2/3] Extracting and syncing files..." -ForegroundColor Yellow
        $ExtractPath = Join-Path $TempDir "extracted"
        Expand-Archive -Path $ZipPath -DestinationPath $ExtractPath -Force
        
        $SourceDir = Get-ChildItem -Path $ExtractPath -Directory
        $SourcePath = $SourceDir[0].FullName

        $PatcherFilesToSkip = "patcher.ps1", "run-patcher.bat", ".patcher_version"
        Sync-FilesWithHashCheck -SourceDirectory $SourcePath -DestinationDirectory (Get-Location) -FilesToSkip $PatcherFilesToSkip
        
        # --- Step 4: Update local version file on success ---
        Write-Host "`n[3/3] Finalizing update..." -ForegroundColor Yellow
        if ($RemoteCommitHash) {
            Set-Content -Path $LocalVersionFile -Value $RemoteCommitHash
            Write-Host "      Local version updated to $($RemoteCommitHash.Substring(0,8))."
        } else {
            Write-Host "      Download succeeded, but the remote commit hash was unavailable." -ForegroundColor Yellow
        }
        
        Write-Host "`nPatching process finished successfully." -ForegroundColor Green

    } catch {
        Write-Host "`n---! AN ERROR OCCURRED !---" -ForegroundColor Red
        Write-Host "Error details: $($_.Exception.Message)" -ForegroundColor Red
        Write-Host "The process has been stopped. Your local version file has NOT been updated."
    } finally {
        if (Test-Path $TempDir) { Remove-Item -Path $TempDir -Recurse -Force }
    }
}

# --- Main Execution ---
if ($RepoURL -eq "https://gitgud.io/example-user/example-repo") {
    Write-Host "---! CONFIGURATION NEEDED !---" -ForegroundColor Red
    Write-Host "Please right-click and edit 'patcher.ps1', then change the `$RepoURL variable."
} elseif (Show-Confirmation) {
    Start-Patch
}

Write-Host "`n============================================================"
Write-Host "The patcher has finished. You can review the output above."