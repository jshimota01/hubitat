# Notes
-Object Effects in Save/Load remain untranslated.