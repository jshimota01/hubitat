# TL Patch for 3SLG IE
## Usage

1. Put the files into the gameroot folder
2. Play by launching tj3slgie.exe
3. Use patch.bat for updates (Windows only)

## Notes on the .dll
The .dll are not mandatory but do translate system messages (achievement, quit, return to title). Without .dll the game needs to be installed via disc and saves would be found inside appdata.

## Credits
It wouldn't have been possible without len, Elyon and The VN connoisseur and their coding expertise.
GPT4.1 has been used for the translation ($20 for ~800k words)