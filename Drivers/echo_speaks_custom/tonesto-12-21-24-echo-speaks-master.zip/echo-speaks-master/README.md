<p align="center"><img src="https://raw.githubusercontent.com/tonesto7/echo-speaks/master/resources/icons/EchoSpeaks.png"></p>
<h2 align="center">
  Welcome to Echo Speaks
</h2>

<p align="center">
  <b>Links:</b><br>
  <a href="https://tonesto7.github.io/echo-speaks-docs">Documentation</a> |
  <a href="https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=HWBN4LB9NMHZ4">Donations</a>
</p>

<h4>Description:</h4>
<p>Integrate your Amazon Echo devices into your Hubitat environment to create virtual Echo Devices. These virtual devices will allow you to speak text, make announcements, control media playback including volume, and many other Alexa features.</p>

